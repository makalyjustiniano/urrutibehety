* `Tecnativa <https://www.tecnativa.com>`_

  * Pedro M. Baeza
  * David Vidal
  * Carlos Dauden
  * Rafael Blasco
  * Ernesto Tejeda
* Omar Castiñeira <omar@comunitea.com>
