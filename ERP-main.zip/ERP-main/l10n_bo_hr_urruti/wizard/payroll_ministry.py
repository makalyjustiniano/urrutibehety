from odoo import fields, models, _
from datetime import datetime, timedelta, date


class PayrollMinistry(models.TransientModel):
    _inherit = "payroll.ministry"

    planilla_id = fields.Selection([('11', '11'), ('12', '12'), ('13', '13'), ('14', '14'), ('15', '15')],
                                   string='Planilla', required=True, default='11')

    def print_xlsx(self):
        plani = dict(self._fields['planilla_id'].selection).get(self.planilla_id)
        report_name = 'l10n_bo_hr.payroll_a_xlsx.xlsx'
        if plani == '12':
            report_name = 'l10n_bo_hr.payroll_a_xlsx_12.xlsx'
        if plani == '13':
            report_name = 'l10n_bo_hr.payroll_a_xlsx_13.xlsx'
        if plani == '14':
            report_name = 'l10n_bo_hr.payroll_a_xlsx_14.xlsx'
        if plani == '15':
            report_name = 'l10n_bo_hr.payroll_a_xlsx_15.xlsx'
        return self.env['ir.actions.report'].search(
            [('report_name', '=', report_name),
             ('report_type', '=', 'xlsx')], limit=1).report_action(self)
