# -*- coding: utf-8 -*-
# from . import hr_retroactivo
from . import hr_finiquito
from . import hr_employee
from . import hr_payslip
from . import hr_contract
from . import hr_leave_allocation
