from odoo import models, fields, api
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError


class Employee(models.Model):
    _inherit = 'hr.employee'

    date_init_company = fields.Date(string='Fecha de ingreso a la empresa')

    @api.constrains('name', 'company_id', 'tipo_doc', 'identification_id', 'expedido')
    def _check_unique_identification(self):
        for rec in self:
            domain = [
                ('company_id', '=', rec.company_id.id),
                ('id', '!=', rec.id),
                ('tipo_doc', '=', rec.tipo_doc),
                ('identification_id', '=', rec.identification_id),
                ('expedido', '=', rec.expedido),
            ]
            employee = rec.search(domain)
            if rec.search(domain):
                raise ValidationError('Existe la identificacion con el empleado ' + str(employee[0].name))
