from odoo import models, fields, api, _, tools
from datetime import datetime
from datetime import date
from dateutil import relativedelta


class HrFiniquito(models.Model):
    _inherit = "hr.finiquito"

    @api.onchange('payslip_one_id')
    def onchange_payslip_one_id(self):
        for fini in self:
            if fini.type_irru == 's11':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NET' or x.code == 'NETBO'):
                    fini.first_amount = s.total
            elif fini.type_irru == 's12':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO12'):
                    fini.first_amount = s.total
            elif fini.type_irru == 's13':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO13'):
                    fini.first_amount = s.total
            elif fini.type_irru == 's14':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO14'):
                    fini.first_amount = s.total
            elif fini.type_irru == 's15':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO15'):
                    fini.first_amount = s.total

    @api.onchange('payslip_second_id')
    def onchange_payslip_second_id(self):
        for fini in self:
            if fini.type_irru == 's11':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NET' or x.code == 'NETBO'):
                    fini.second_amount = s.total
            elif fini.type_irru == 's12':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO12'):
                    fini.second_amount = s.total
            elif fini.type_irru == 's13':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO13'):
                    fini.second_amount = s.total
            elif fini.type_irru == 's14':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO14'):
                    fini.second_amount = s.total
            elif fini.type_irru == 's15':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO15'):
                    fini.second_amount = s.total

    @api.onchange('payslip_third_id')
    def onchange_payslip_third_id(self):
        for fini in self:
            if fini.type_irru == 's11':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NET' or x.code == 'NETBO'):
                    fini.third_amount = s.total
            elif fini.type_irru == 's12':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO12'):
                    fini.third_amount = s.total
            elif fini.type_irru == 's13':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO13'):
                    fini.third_amount = s.total
            elif fini.type_irru == 's14':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO14'):
                    fini.third_amount = s.total
            elif fini.type_irru == 's15':
                for s in fini.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                        lambda x: x.code == 'NETBO15'):
                    fini.third_amount = s.total

    @api.onchange('employee_id', 'type_irru')
    def onchange_employee_id(self):
        if self.employee_id.contract_id:
            self.contract_id = self.employee_id.contract_id.id
            if self.type_irru == 's11':
                self.date_from = self.contract_id.date_start
            elif self.type_irru == 's12':
                self.date_from = self.contract_id.date_start_12
            elif self.type_irru == 's13':
                self.date_from = self.contract_id.date_start_13
            elif self.type_irru == 's14':
                self.date_from = self.contract_id.date_start_14
            elif self.type_irru == 's15':
                self.date_from = self.contract_id.date_start_15
            payslip_ids = self.env['hr.payslip'].search(
                [('employee_id', '=', self.employee_id.id), ('state', '=', 'done')], limit=3, order="date_from desc")
            for index, p in enumerate(payslip_ids):
                if index == 0:
                    self.payslip_third_id = p.id
                    self.payslip_second_id = False
                    self.payslip_one_id = False
                elif index == 1:
                    self.payslip_second_id = p.id
                    self.payslip_one_id = False
                elif index == 2:
                    self.payslip_one_id = p.id
            if not payslip_ids:
                self.payslip_third_id = False
                self.payslip_second_id = False
                self.payslip_one_id = False
        else:
            self.contract_id = False
            self.date_from = False
            self.payslip_third_id = False
            self.payslip_second_id = False
            self.payslip_one_id = False

    type_irru = fields.Selection(string='Nro Salario',
                                 selection=[('s11', 'Salario'),
                                            ('s12', 'Salario 12'),
                                            ('s13', 'Salario 13'),
                                            ('s14', 'Salario 14'),
                                            ('s15', 'Salario 15')],
                                 copy=False, default='s11')
