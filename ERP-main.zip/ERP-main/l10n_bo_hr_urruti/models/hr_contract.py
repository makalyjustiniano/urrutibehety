# -*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import logging

from datetime import date
from dateutil.relativedelta import relativedelta

from odoo import api, fields, models, _
from odoo.models import MAGIC_COLUMNS
from odoo.fields import Date
from odoo.exceptions import ValidationError
from odoo.tools import html_sanitize

_logger = logging.getLogger(__name__)


class HrContract(models.Model):
    _inherit = 'hr.contract'

    x_studio_salario_12 = fields.Monetary(string='Salario 12')
    x_studio_salario_13 = fields.Monetary(string='Salario 13')
    x_studio_salario_14 = fields.Monetary(string='Salario 14')
    x_studio_salario_15 = fields.Monetary(string='Salario 15')
    date_start_12 = fields.Date('Fecha Asignación 12', required=True, default=fields.Date.today, tracking=True, index=True)
    date_end_12 = fields.Date('Fecha Fin Asignación 12', tracking=True)
    date_start_13 = fields.Date('Fecha Asignación 13', required=True, default=fields.Date.today, tracking=True,
                                index=True)
    date_end_13 = fields.Date('Fecha Fin Asignación 13', tracking=True)
    date_start_14 = fields.Date('Fecha Asignación 14', required=True, default=fields.Date.today, tracking=True,
                                index=True)
    date_end_14 = fields.Date('Fecha Fin Asignación 14', tracking=True)
    date_start_15 = fields.Date('Fecha Asignación 15', required=True, default=fields.Date.today, tracking=True,
                                index=True)
    date_end_15 = fields.Date('Fecha Fin Asignación 15', tracking=True)

    @api.depends(lambda self: (
            'wage',
            'x_studio_salario_12',
            'x_studio_salario_13',
            'x_studio_salario_14',
            'x_studio_salario_15',
            'structure_type_id.salary_advantage_ids.res_field_id',
            'structure_type_id.salary_advantage_ids.impacts_net_salary',
            *self._get_advantage_fields()))
    def _compute_final_yearly_costs(self):
        for contract in self:
            contract.final_yearly_costs = contract._get_advantages_costs() + contract._get_salary_costs_factor() * (
                    contract.wage + contract.x_studio_salario_12 + contract.x_studio_salario_13 + contract.x_studio_salario_14 + contract.x_studio_salario_15)

    @api.onchange('final_yearly_costs')
    def _onchange_final_yearly_costs(self):
        final_yearly_costs = self.final_yearly_costs
        #self.wage = self._get_gross_from_employer_costs(final_yearly_costs)
        self.env.remove_to_compute(self._fields['final_yearly_costs'], self)
        self.final_yearly_costs = final_yearly_costs
