from odoo import models, fields, api


class Payslip(models.Model):
    _inherit = 'hr.payslip'

    def _get_base_local_dict(self):
        res = super()._get_base_local_dict()
        res.update({
            'calculo_bono_antiguedad_empleado': calculo_bono_antiguedad_empleado,
            'calculo_bono_antiguedad_empleado_anterior': calculo_bono_antiguedad_empleado_anterior,
        })
        return res

# Funciones adicionales calculo HHRR Bolivia
def calculo_bono_antiguedad_empleado(payslip):
    contract = payslip.contract_id
    bono = payslip.dict.env['hr.bono.antiguedad']
    start = contract.employee_id.date_init_company
    end = payslip.date_to
    number_of_month = (end.year - start.year) * 12 + (end.month - start.month) + 1
    year = round(number_of_month / 12, 2)
    busqueda_bono = bono.search([('anio_min', '<=', year), ('anio_max', '>', year)])
    monto_bono = 0
    if busqueda_bono:
        monto_bono = (contract.company_id.sueldo_min * 3) * (busqueda_bono[0].porcentaje / 100)
    return monto_bono


# Funciones adicionales calculo HHRR Bolivia
def calculo_bono_antiguedad_empleado_anterior(payslip):
    contract = payslip.contract_id
    bono = payslip.dict.env['hr.bono.antiguedad']
    start = contract.employee_id.date_init_company
    end = payslip.date_to
    number_of_month = (end.year - start.year) * 12 + (end.month - start.month) + 1
    year = round(number_of_month / 12, 2)
    busqueda_bono = bono.search([('anio_min', '<=', year), ('anio_max', '>', year)])
    monto_bono = 0
    if busqueda_bono:
        monto_bono = (contract.company_id.sueldo_min_ant * 3) * (busqueda_bono[0].porcentaje / 100)
    return monto_bono

