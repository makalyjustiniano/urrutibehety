# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

# STATES = [('1','1'),('2','2'),('3','3'),('4','4'),('5','5'),('6','6'),('7','7'),('8','8'),('9','9'),('10','10')]

class QuoteTypeOperator(models.Model):
    _name = 'quote.type.operator'
    _description = 'Quote Type Operator'

    name = fields.Char()
    operator_type = fields.Char()


class DraftQuotation(models.Model):
    _name = 'draft.quotation'
    _description = 'Draft Quotation'
    _rec_name = 'reference_no'

    # quotation_ids = fields.Many2many('sale.order',string = 'Quotations')
    quotation_count = fields.Integer(string="Quotations Count",compute="get_quotation_count")

    # @api.depends('quotation_ids')
    def get_quotation_count(self):
        # self.quotation_count = len(self.quotation_ids.ids)

        orders = self.env['sale.order'].search_count([('d_quotation_id','=',self.id)])
        self.quotation_count = orders


    def action_open_quotations(self):
        self.ensure_one()
        
        orders = self.env['sale.order'].search([('d_quotation_id','=',self.id)])
        action = self.env['ir.actions.actions']._for_xml_id('sale.action_quotations_with_onboarding')
        if len(orders) > 1:
            action['domain'] = [('id', 'in', orders.ids)]
        elif len(orders) == 1:
            form_view = [(self.env.ref('sale.view_order_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state,view) for state,view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = orders.id
        else:
            action = {'type': 'ir.actions.act_window_close'}

        context = {
            'create': False,
        }

        action['context'] = context
        return action


    # product_id = fields.Many2one('product.type',string="Products")

    reference_no = fields.Char(string='Order Reference', required=True,readonly=True, default=lambda self: _('New'))
    date_quotation = fields.Datetime('Quotation date' , required=False, default=lambda self: fields.datetime.now())


    @api.model
    def create(self, vals):
        if vals.get('reference_no', _('New')) == _('New'):
            vals['reference_no'] = self.env['ir.sequence'].next_by_code('draft.quotation') or _('New')
        res = super(DraftQuotation, self).create(vals)
        return res


    INM = fields.Integer(compute="_compute_locations",string="Locaciones",readonly=True)
    pisos_resumen = fields.Integer(compute="_compute_pisos",string="Pisos",readonly=True)
    alfombras_resumen = fields.Integer(compute="_compute_alfombra",string="Alfombras",readonly=True)
    vidrios_resumen = fields.Integer(compute="_compute_vidrios",string="Vidrios",readonly=True)
    muebles_resumen = fields.Integer(compute="_compute_muebles",string="Muebles",readonly=True)
    otros_resumen = fields.Integer(compute="_compute_otros",string="Otros",readonly=True)

    CFUN = fields.Integer(string="Funcionarios",compute="_compute_banos",readonly=True)
    CBAN = fields.Integer(string="Banos",compute="_compute_banos",readonly=True)
    CINO = fields.Integer(string="Inodoros",compute="_compute_banos",readonly=True)
    CURI = fields.Integer(string="Urinarios",compute="_compute_banos",readonly=True)
    CDUC = fields.Integer(string="Duchas",compute="_compute_banos",readonly=True)
    papel_higienico_resumen = fields.Integer(compute="_compute_papel_higienico",string="Papel Higienico")

    company_id = fields.Many2one('res.company',string="Company",default=lambda self: self.env.company)

    location_id_resumen = fields.Many2one('location.type',string="Locación")
    COPE = fields.Integer(string="Operarios",compute="_compute_operators_count",readonly=True)
    temporary_resumen = fields.Integer(string="Eventuales",readonly=True)
    cubrelibres_resumen = fields.Integer(string="Cubrelibres",readonly=True)
    supervis_resumen = fields.Integer(string="Supervis",readonly=True)
    holidays_resumen = fields.Integer(string="Feriados",readonly=True)
    total_area_resumen = fields.Integer(string="Area Total",readonly=True)



    tipo_de_location_id_locaciones = fields.Many2one('location.type',string="Tipo de Locación")
    # tipo_de_location_id_locaciones = fields.Selection([('departamento','Departamento'),('casa','Casa'),('edificio','Edificio')],'Tipo de Locación')
    pisos_locaciones = fields.Integer(string="Pisos")
    name_location_locaciones = fields.Char(string="Nombre Locación")
    is_hospital_or_clinic_locaciones = fields.Selection([('yes','Si'),('no','No')],'Es Hospital o Clínica')

    location_lines_ids = fields.One2many('locacione.lines','locacione_quotation_id')



    # tipo_de_piso_id_pisos = fields.Many2one('piso.piso',string="Tipo de Piso")
    tipo_de_piso_id_pisos = fields.Selection([('porcelanato','Porcelanato'),('ceramica_esmaltada','Cerámica Esmaltada'),('PIS01_1','Granito'),('PIS01_2','Vinil'),('PIS01_3','Mosaico'),('PIS03','Madera'),('editicioMarmol','EditicioMármol'),('PIS02','Céramica Roja'),('cemento','Cemento'),('ladrillo','Ladrillo'),('flotante','Flotante'),('piso_pac','Piso Pac')],'Tipo de Piso')
    m2_pisos = fields.Integer(string="m2")
    locacion_en_la_que_cotiza_id_pisos = fields.Many2one('locacione.lines',string="Locacion en la que cotiza", domain="[('id', 'in', location_lines_ids)]")
    piso_lines_ids = fields.One2many('piso.lines','piso_quotation_id')



    # tipo_de_alfombra_alfombras = fields.Many2one('alfombra.alfombra', string="Tipo de Alfombra")
    tipo_de_alfombra_alfombras = fields.Selection([('alfombra','Alfombra'),('alfombra de pelo alto','Alfombra de pelo alto'),('tapizon','Tapizón')],'Tipo de Alfombra')
    m2_alfombras = fields.Integer(string="m2")
    locacion_en_la_que_cotiza_id_alfombras = fields.Many2one('locacione.lines', string="Locacion en la que cotiza", domain="[('id', 'in', location_lines_ids)]")
    alfombra_lines_ids = fields.One2many('alfombra.lines','alfombra_quotation_id')



    # ubicacion_del_vidrio_id_vidrios = fields.Many2one('vidrio.vidrio', string="Ubicacion del vidrio")
    ubicacion_del_vidrio_id_vidrios = fields.Selection([('bajos normales','Bajos Normales'),('itos de fácil acceso','ltos de fácil acceso'),('altos de difícil acceso','Altos de difícil acceso')],'Ubicacion del vidrio')
    m2_vidrios = fields.Integer(string="m2")
    locacion_en_la_que_cotiza_id_vidrios = fields.Many2one('locacione.lines', string="Locacion en la que cotiza", domain="[('id', 'in', location_lines_ids)]")
    vidrio_lines_ids = fields.One2many('vidrio.lines','vidrio_quotation_id')



    # tipo_de_material_muebles = fields.Many2one('furniture.piece', string="Tipo de Material")
    tipo_de_material_muebles = fields.Selection([('MUEB1','Cuero'),('MUEB2','Tela'),('MUEB3','Madera'),('MUEB4','Melamina'),('MUEB5','Tapiz'),('MUEB6','Otro')],'Tipo de Material')
    cant_unid_muebles = fields.Integer(string="Cant Unid")
    locacion_en_la_que_cotiza_id_muebles = fields.Many2one('locacione.lines', string="Locacion en la que cotiza", domain="[('id', 'in', location_lines_ids)]")
    mueble_lines_ids = fields.One2many('mueble.lines','mueble_quotation_id')



    banos_banos = fields.Integer('Banos')
    inodoros_banos = fields.Integer("Inodoros")
    urinarios_banos = fields.Integer("Urinarios")
    duchas_banos = fields.Integer("Duchas")
    funcionarios_banos = fields.Integer("Funcionarios")



    medianos_estandar_banos = fields.Integer("Medianos, estandar")
    medianos_colores_banos = fields.Integer("Medianos, colores")
    grandes_estandar_banos = fields.Integer("Grandes, estandar")
    grandes_de_colores_banos = fields.Integer("Grandes, de colores")

    locacion_banos = fields.Many2one('locacione.lines', string="Locacion", domain="[('id', 'in', location_lines_ids)]")

    material_higienico_banos = fields.Boolean('Material Higienico')
    papel_higienico_banos = fields.Selection([('institucional','Institucional'),('rollo_normal','Rollo Normal')],'Papel Higienico')

    banos_lines_ids = fields.One2many('banos.lines','banos_quotation_id')



    # descripcion_otros = fields.Many2one('otro.otro', string="Descripcion")
    descripcion_otros = fields.Selection([('cocinas','Cocinas'),('cocineta','Cocineta'),('ascensores','Ascensores'),('gradas','Gradas'),('basurero contenedor','Basurero Contenedor')],'Descripcion')
    cant_unid_otros = fields.Integer(string="Cant Unid")
    locacion_en_la_que_cotiza_id_otros = fields.Many2one('locacione.lines', string="Locacion en la que cotiza", domain="[('id', 'in', location_lines_ids)]")
    otro_lines_ids = fields.One2many('otro.lines','otro_quotation_id')



    detalle_el_elemento_a_excluir_exclusiones = fields.Char(string="Detalle el elemento a excluir")
    exclusiones_agregadas_exclusiones = fields.Text(string="Exclusiones Agregadas")
    exclusione_lines_ids = fields.One2many('exclusione.lines','exclusione_quotation_id')



    # descripcion_maquinaria = fields.Many2one('machinery.machinery',string="Descripcion")
    descripcion_maquinaria = fields.Selection([('MYE01','ALFA ECO (Aspiradora/Lavadora Grande)'),('MYE02','ALFA MINI (Aspiradora/Lavadora)'),('MYE03','ASPIRADORA AGUA / POLVO'),('MYE04','ASPIRADORA POLVO'),('MYE05','ASPIRADORA VIAL'),('MYE06','BARREDORA KARCHER'),('MYE07','BARREDORA KARCHER KM 7020C'),('MYE08','BARREDORA HOM A BORDO KARCHER KM 100/100 RG'),('MYE09','ELEVADOR TIJERA'),('MYE10','ELEVADOR HIDRAULICO'),('MYE11','ESCALERA'),('MYE12','ESTACION ELECTROSTATICA'),('MYE13','HIDROLAVADORA'),('MYE14','HIDROLAVADORA AUTONOMA HD 6/15'),('MYE15','LAVADORA GRANDE'),('MYE16','LAVADORA ASPIRADORA KARCHER BD 50/50 '),('MYE17','LAVADORA  HOMBRE A BORDO KARCHER B-90'),('MYE18','LUSTRADORA'),('MYE19','LUSTRADORA KARCHER BDP 50/1500 C'),('MYE20','MOCHILA A MOTOR'),('MYE21','MOCHILA ELECTROSTÁTICA'),('MYE22','MOCHILA MANUAL')],'Descripcion')
    cantidad_maquinaria = fields.Integer(string="Cantidad")
    locacion_en_la_que_cotiza_id_maquinaria = fields.Many2one('locacione.lines', string="Locacion en la que cotiza", domain="[('id', 'in', location_lines_ids)]")
    machinery_lines_ids = fields.One2many('maquinaria.lines','maquinaria_quotation_id')


    # employee_id_operator = fields.Many2one('employee.employee',string="Employee")
    locacion_operator = fields.Many2one('locacione.lines', string="Locacion", domain="[('id', 'in', location_lines_ids)]")
    # quot_type_operator_id = fields.Selection([('COPE','Operarios'),('temporary_resumen','Eventuales'),('cubrelibres_resumen','Cubrelibres'),('supervis_resumen','Supervis'),('holidays_resumen','Feriados'),('total_area_resumen','Area Total')],'Quot Type')
    quot_type_operator_id = fields.Many2one('product.type', string='Quote Type')    
    type_hoas_operator = fields.Integer(string='Horas')
    # type_8_hoas_operator = fields.Integer(string='8 Horas')
    # type_10_hoas_operator = fields.Integer(string='10 Horas')
    # type_12_hoas_operator = fields.Integer(string='12 Horas')
    # total_hoas_operator = fields.Integer(string="Total Horas",compute="_compute_total_horas",readonly=True)
    operator_lines_ids = fields.One2many('operator.lines','operator_quotation_id')

    def submit_locaciones(self):
        # import pdb;pdb.set_trace()
        if self.tipo_de_location_id_locaciones:
            self.location_lines_ids.create({'type_product_cotizador':'locaciones','cotiza_product': self.name_location_locaciones,'cant': self.pisos_locaciones,'locacion_product_line': self.tipo_de_location_id_locaciones.id,'locacione_quotation_id':self.id})

            self.tipo_de_location_id_locaciones = False
            self.pisos_locaciones = 0
            self.name_location_locaciones = False
            self.is_hospital_or_clinic_locaciones = False


    def submit_pisos(self):
        if self.locacion_en_la_que_cotiza_id_pisos:

            self.piso_lines_ids.create({'type_product_cotizador':'pisos','cotiza_product_id': self.tipo_de_piso_id_pisos,'cant': self.m2_pisos,'locacion_product_line':self.locacion_en_la_que_cotiza_id_pisos.id,'piso_quotation_id':self.id})

            self.locacion_en_la_que_cotiza_id_pisos = False
            self.m2_pisos = 0
            self.tipo_de_piso_id_pisos = False


    def submit_alfombras(self):
        if self.locacion_en_la_que_cotiza_id_alfombras:

            self.alfombra_lines_ids.create({'type_product_cotizador':'alfombras','cotiza_product_id': self.tipo_de_alfombra_alfombras,'cant': self.m2_alfombras,'locacion_product_line':self.locacion_en_la_que_cotiza_id_alfombras.id,'alfombra_quotation_id':self.id})

            self.locacion_en_la_que_cotiza_id_alfombras = False
            self.tipo_de_alfombra_alfombras = False
            self.m2_alfombras = 0



    def submit_vidrios(self):
        if self.locacion_en_la_que_cotiza_id_vidrios:

            self.vidrio_lines_ids.create({'type_product_cotizador':'vidrios','cotiza_product_id': self.ubicacion_del_vidrio_id_vidrios,'cant': self.m2_vidrios,'locacion_product_line':self.locacion_en_la_que_cotiza_id_vidrios.id,'vidrio_quotation_id':self.id})

            self.locacion_en_la_que_cotiza_id_vidrios = False
            self.ubicacion_del_vidrio_id_vidrios = False
            self.m2_vidrios = 0



    def submit_muebles(self):
        if self.locacion_en_la_que_cotiza_id_muebles:

            self.mueble_lines_ids.create({'type_product_cotizador':'muebles','cotiza_product_id': self.tipo_de_material_muebles,'cant': self.cant_unid_muebles,'locacion_product_line':self.locacion_en_la_que_cotiza_id_muebles.id,'mueble_quotation_id':self.id})

            self.locacion_en_la_que_cotiza_id_muebles = False
            self.tipo_de_material_muebles = False
            self.cant_unid_muebles = 0



    def submit_otros(self):
        if self.locacion_en_la_que_cotiza_id_otros:

            self.otro_lines_ids.create({'type_product_cotizador':'otros','cotiza_product_id': self.descripcion_otros,'cant': self.cant_unid_otros,'locacion_product_line':self.locacion_en_la_que_cotiza_id_otros.id,'otro_quotation_id':self.id})

            self.locacion_en_la_que_cotiza_id_otros = False
            self.descripcion_otros = False
            self.cant_unid_otros = 0


    def submit_maquinaria(self):
        if self.locacion_en_la_que_cotiza_id_maquinaria:

            self.machinery_lines_ids.create({'type_product_cotizador':'maquinaria','cotiza_product_id': self.descripcion_maquinaria,'cant': self.cantidad_maquinaria,'locacion_product_line':self.locacion_en_la_que_cotiza_id_maquinaria.id,'maquinaria_quotation_id':self.id})

            self.locacion_en_la_que_cotiza_id_maquinaria = False
            self.descripcion_maquinaria = False
            self.cantidad_maquinaria = 0



    def submit_exclusione(self):
        if self.detalle_el_elemento_a_excluir_exclusiones:

            self.exclusione_lines_ids.create({'type_product_cotizador':'exclusiones','cotiza_product': self.detalle_el_elemento_a_excluir_exclusiones,'cant': 1,'locacion_product_line':'Client','exclusione_quotation_id':self.id})

            self.detalle_el_elemento_a_excluir_exclusiones = False



    def submit_banos(self):
        if self.locacion_banos:

            self.banos_lines_ids.create({'type_product_cotizador':'banos','locacion_product_line':self.locacion_banos.id,'banos_cant':int(self.banos_banos),'inodoros_cant':int(self.inodoros_banos),'urinarios_cant':int(self.urinarios_banos),'duchas_cant':int(self.duchas_banos),'funcionarios_cant':int(self.funcionarios_banos),'medianos_estandar_cant':int(self.medianos_estandar_banos),'medianos_colores_cant':int(self.medianos_colores_banos),'grandes_estandar_cant':int(self.grandes_estandar_banos),'grandes_decolores_cant':int(self.grandes_de_colores_banos),'papel_higienico':self.papel_higienico_banos,'banos_quotation_id':self.id})

            self.locacion_banos = False
            self.banos_banos = False
            self.inodoros_banos = False
            self.urinarios_banos = False
            self.duchas_banos = False
            self.funcionarios_banos = False
            self.medianos_estandar_banos = False
            self.medianos_colores_banos = False
            self.grandes_estandar_banos = False
            self.grandes_de_colores_banos = False
            self.material_higienico_banos = False
            self.papel_higienico_banos = False



    def submit_operator(self):
        if self.locacion_operator:

            self.operator_lines_ids.create({'type_product_cotizador':'operator','locacion_product_line':self.locacion_operator.id,'quot_type': self.quot_type_operator_id.id,'employee_count':self.type_hoas_operator,'operator_quotation_id':self.id})

            self.locacion_operator = False
            self.quot_type_operator_id = False
            self.type_hoas_operator = 0


    @api.depends('location_lines_ids')
    def _compute_locations(self):
        c = 0
        l = []
        for rec in self.location_lines_ids:
            if rec.locacion_product_line.id not in l:
                l.append(rec.locacion_product_line.id)
                c += 1
        self.INM = c


    @api.depends('piso_lines_ids')
    def _compute_pisos(self):
        c = 0
        for rec in self.piso_lines_ids:
            c += rec.cant
        self.pisos_resumen = c


    @api.depends('alfombra_lines_ids')
    def _compute_alfombra(self):
        c = 0
        for rec in self.alfombra_lines_ids:
            c += rec.cant
        self.alfombras_resumen = c


    @api.depends('vidrio_lines_ids')
    def _compute_vidrios(self):
        c = 0
        for rec in self.vidrio_lines_ids:
            c += rec.cant
        self.vidrios_resumen = c


    @api.depends('mueble_lines_ids')
    def _compute_muebles(self):
        c = 0
        for rec in self.mueble_lines_ids:
            c += rec.cant
        self.muebles_resumen = c


    @api.depends('otro_lines_ids')
    def _compute_otros(self):
        c = 0
        for rec in self.otro_lines_ids:
            c += rec.cant
        self.otros_resumen = c


    @api.depends('banos_lines_ids')
    def _compute_banos(self):
        fc,bc,ic,uc,dc = 0,0,0,0,0
        for rec in self.banos_lines_ids:
            fc += rec.funcionarios_cant
            bc += rec.banos_cant
            ic += rec.inodoros_cant
            uc += rec.urinarios_cant
            dc += rec.duchas_cant
        self.CFUN = fc
        self.CBAN = bc
        self.CINO = ic
        self.CURI = uc
        self.CDUC = dc


    @api.depends('operator_lines_ids')
    def _compute_operators(self):
        # oc,tc,cc,sc,hc,ac = 0,0,0,0,0,0
        #     for rec in self.operator_lines_ids:
        #         if rec.quot_type == "COPE":
        #             oc = oc + rec.employee_count
        #         elif rec.quot_type == "temporary_resumen":
        #             tc = tc + rec.employee_count
        #         elif rec.quot_type == "cubrelibres_resumen":
        #             cc = cc + rec.employee_count
        #         elif rec.quot_type == "supervis_resumen":
        #             sc = sc + rec.employee_count
        #         elif rec.quot_type == "holidays_resumen":
        #             hc = hc + rec.employee_count
        #         elif rec.quot_type == "total_area_resumen":
        #             ac = ac + rec.employee_count
        #     self.COPE = oc
        #     self.temporary_resumen = tc
        #     self.cubrelibres_resumen = cc
        #     self.supervis_resumen = sc
        #     self.holidays_resumen = hc
        #     self.total_area_resumen = ac

        self.temporary_resumen = 0
        self.cubrelibres_resumen = 0
        self.supervis_resumen = 0
        self.holidays_resumen = 0
        self.total_area_resumen = 0


    @api.depends('operator_lines_ids')
    def _compute_operators_count(self):
        oc = 0
        for rec in self.operator_lines_ids:
            oc = oc + rec.employee_count
        self.COPE = oc

    @api.depends('CFUN','CBAN','CINO','CURI','CDUC')
    def _compute_papel_higienico(self):
        self.papel_higienico_resumen = self.CFUN + self.CBAN + self.CINO + self.CURI + self.CDUC



    # @api.onchange('type_4_hoas_operator','type_8_hoas_operator','type_10_hoas_operator','type_12_hoas_operator')
    # def _compute_total_horas(self):
    #     self.total_hoas_operator = self.type_4_hoas_operator + self.type_8_hoas_operator + self.type_10_hoas_operator + self.type_12_hoas_operator
