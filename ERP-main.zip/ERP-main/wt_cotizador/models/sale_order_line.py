# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    locacion_order_line = fields.Many2one('location.type', string="Locacion")
    type_product_cotizador = fields.Selection([('locaciones','Locaciones'),('pisos','Pisos'),('alfombras','Alfombras'),('vidrios','Vidrios'),('muebles','Muebles'),('banos','Banos'),('otros','Otros'),('exclusiones','Exclusiones'),('maquinaria','Maquinaria')],'Product Type')

    product_uom_qty = fields.Float(string='Quantity', digits='Product Unit of Measure', required=True, default=1.0 , compute="get_product_qty")
 
