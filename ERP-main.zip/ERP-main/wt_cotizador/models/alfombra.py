# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Alfombra(models.Model):
    _name = 'alfombra.alfombra'
    _description = "Alfombra Details"

    name = fields.Char(string="Alfombra",required=True)
    description = fields.Char(string="Descripción")