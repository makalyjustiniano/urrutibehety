from . import location
from . import product_product
from . import elements
from . import product_lines
from . import draft_quotation
from . import dq_wizard
from . import sale_order
from . import product_type
from . import service_product
# from . import tipo_location
# from . import sale_order_line