# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class TipoLocation(models.Model):
    _name = 'tipo.location'
    _description = "Tipo Location"

    name = fields.Char(string="Tipo Locación",required=True)
    description = fields.Char(string="Descripción")