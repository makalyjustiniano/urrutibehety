# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class ProductCategory(models.Model):
	_inherit= "product.category"
	_description = "Product Category"

	name = fields.Char(string="Categoría",required=True)
	description = fields.Char(string="Descripción")
