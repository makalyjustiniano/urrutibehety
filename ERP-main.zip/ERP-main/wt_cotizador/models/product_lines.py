# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

product_type_list = [('locaciones','Locaciones'),('pisos','Pisos'),('alfombras','Alfombras'),('vidrios','Vidrios'),('muebles','Muebles'),('banos','Banos'),('otros','Otros'),('exclusiones','Exclusiones'),('maquinaria','Maquinaria'),('operator','Operator')]


class LocacioneLines(models.Model):
    _name = 'locacione.lines'
    _description = 'Locaciones Lines'
    _rec_name = 'cotiza_product'

    locacione_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    cotiza_product = fields.Char(string='Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('location.type', string="Locacion Type")
    # locacion_product_line = fields.Selection([('departamento','Departamento'),('casa','Casa'),('edificio','Edificio')],'Locacion Type')


class PisoLines(models.Model):
    _name = 'piso.lines'
    _description = 'Piso Lines'

    piso_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    # cotiza_product_id = fields.Many2one('piso.piso',string='Tipo')
    cotiza_product_id = fields.Selection([('porcelanato','Porcelanato'),('ceramica_esmaltada','Cerámica Esmaltada'),('PIS01_1','Granito'),('PIS01_2','Vinil'),('PIS01_3','Mosaico'),('PIS03','Madera'),('editicioMarmol','EditicioMármol'),('PIS02','Céramica Roja'),('cemento','Cemento'),('ladrillo','Ladrillo'),('flotante','Flotante'),('piso_pac','Piso Pac')],'Tipo')

    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")


class AlfombraLines(models.Model):
    _name = 'alfombra.lines'
    _description = 'Alfombra Lines'

    alfombra_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    # cotiza_product_id = fields.Many2one('alfombra.alfombra',string='Tipo')
    cotiza_product_id = fields.Selection([('alfombra','Alfombra'),('alfombra de pelo alto','Alfombra de pelo alto'),('tapizon','Tapizón')],'Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")


class VidrioLines(models.Model):
    _name = 'vidrio.lines'
    _description = 'Vidrio Lines'

    vidrio_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    # cotiza_product_id = fields.Many2one('vidrio.vidrio',string='Tipo')
    cotiza_product_id = fields.Selection([('bajos normales','Bajos Normales'),('itos de fácil acceso','ltos de fácil acceso'),('altos de difícil acceso','Altos de difícil acceso')],'Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")


class MuebleLines(models.Model):
    _name = 'mueble.lines'
    _description = 'Mueble Lines'

    mueble_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    # cotiza_product_id = fields.Many2one('furniture.piece',string='Tipo')
    cotiza_product_id = fields.Selection([('MUEB1','Cuero'),('MUEB2','Tela'),('MUEB3','Madera'),('MUEB4','Melamina'),('MUEB5','Tapiz'),('MUEB6','Otro')],'Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")


class OtroLines(models.Model):
    _name = 'otro.lines'
    _description = 'Otro Lines'

    otro_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    # cotiza_product_id = fields.Many2one('otro.otro',string='Tipo')
    cotiza_product_id = fields.Selection([('cocinas','Cocinas'),('cocineta','Cocineta'),('ascensores','Ascensores'),('gradas','Gradas'),('basurero contenedor','Basurero Contenedor')],'Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")


class MaquinariaLines(models.Model):
    _name = 'maquinaria.lines'
    _description = 'Maquinaria Lines'

    maquinaria_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    # cotiza_product_id = fields.Many2one('machinery.machinery',string='Tipo')
    cotiza_product_id = fields.Selection([('MYE01','ALFA ECO (Aspiradora/Lavadora Grande)'),('MYE02','ALFA MINI (Aspiradora/Lavadora)'),('MYE03','ASPIRADORA AGUA / POLVO'),('MYE04','ASPIRADORA POLVO'),('MYE05','ASPIRADORA VIAL'),('MYE06','BARREDORA KARCHER'),('MYE07','BARREDORA KARCHER KM 7020C'),('MYE08','BARREDORA HOM A BORDO KARCHER KM 100/100 RG'),('MYE09','ELEVADOR TIJERA'),('MYE10','ELEVADOR HIDRAULICO'),('MYE11','ESCALERA'),('MYE12','ESTACION ELECTROSTATICA'),('MYE13','HIDROLAVADORA'),('MYE14','HIDROLAVADORA AUTONOMA HD 6/15'),('MYE15','LAVADORA GRANDE'),('MYE16','LAVADORA ASPIRADORA KARCHER BD 50/50 '),('MYE17','LAVADORA  HOMBRE A BORDO KARCHER B-90'),('MYE18','LUSTRADORA'),('MYE19','LUSTRADORA KARCHER BDP 50/1500 C'),('MYE20','MOCHILA A MOTOR'),('MYE21','MOCHILA ELECTROSTÁTICA'),('MYE22','MOCHILA MANUAL')],'Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")


class ExclusioneLines(models.Model):
    _name = 'exclusione.lines'
    _description = 'Exclusione Lines'

    exclusione_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    cotiza_product = fields.Char(string='Tipo')
    cant = fields.Integer(string='Cant')
    locacion_product_line = fields.Char(string="Locacion")


class BanosLines(models.Model):
    _name = 'banos.lines'
    _description = 'Banos Lines'
    _rec_name = 'type_product_cotizador'

    banos_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")
    banos_cant = fields.Integer('Banos Cant')
    inodoros_cant = fields.Integer('Inodoros Cant')
    urinarios_cant = fields.Integer('Urinarios Cant')
    duchas_cant = fields.Integer('Duchas Cant')
    funcionarios_cant = fields.Integer(string='Funcionarios Cant')

    medianos_estandar_cant = fields.Integer(string='Medianos,estandar Cant')
    medianos_colores_cant = fields.Integer(string='Medianos,colores Cant')
    grandes_estandar_cant = fields.Integer(string='Grandes,estandar Cant')
    grandes_decolores_cant = fields.Integer(string='Grandes,de colores Cant')
    papel_higienico = fields.Selection([('institucional','Institucional'),('rollo_normal','Rollo Normal')],string='Papel Higienico')


class OperatorLines(models.Model):
    _name = 'operator.lines'
    _description = 'Operator Lines'

    operator_quotation_id = fields.Many2one('draft.quotation')

    type_product_cotizador = fields.Selection(product_type_list,'Product Type')
    employee_count = fields.Integer(string="Quantity")
    locacion_product_line = fields.Many2one('locacione.lines', string="Locacion")
    quot_type = fields.Many2one('product.type',string="Operator Name")
    # quot_count = fields.Integer('Employee Count')