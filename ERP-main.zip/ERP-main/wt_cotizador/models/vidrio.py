# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Vidrio(models.Model):
    _name = 'vidrio.vidrio'
    _description = "Vidrio Details"

    name = fields.Char(string="Vidrio",required=True)
    description = fields.Char(string="Descripción")