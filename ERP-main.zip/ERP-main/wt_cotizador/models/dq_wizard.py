# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
import math

class DqWizard(models.Model):
    _name = 'dq.wizard'
    _description = 'Dq Wizard'

    customer_id = fields.Many2one('res.partner',string="Customer",required=True)
    date_quotation = fields.Datetime('Quotation date' , required=True, default=lambda self: fields.datetime.now())


    def create_sale_order(self):
        # print('Done............')

        dq_record = self._context.get('active_id')
        rec = self.env['draft.quotation'].search([('id','=',dq_record)])

        new = self.env['sale.order'].create({'partner_id':self.customer_id.id,'date_order':self.date_quotation,'origin':str(dq_record),'d_quotation_id':dq_record})
        
        # for product in rec.product_id.line_ids:
        #   def _get_sale_quantity(product_qty,per_unit,pisos_resumen):
        #       if per_unit==0:
        #           per_unit=1
        #       print((pisos_resumen * product_qty)/per_unit)
        #       return math.ceil((pisos_resumen * product_qty)/per_unit)
        #   vals = {'product_id':product.product_id.id,
        #           'product_uom':product.uom_id.id,
        #           'price_unit':product.product_id.list_price,
        #           'product_uom_qty':_get_sale_quantity(product.qty, product.per_unit,rec.pisos_resumen)}
        #   new.write({'order_line':[(0, 0,  vals) ]})

        rec.get_quotation_count()
        # rec.write({'quotation_ids':[(4,new.id)]})

        for operatorline in rec.operator_lines_ids:
            new.operations_ids.create({'operations_id':operatorline.quot_type.id,'qty':operatorline.employee_count,'sale_id':new.id})

        sp_p1_rec = 0
        sp_p2_rec = 0
        sp_p3_rec = 0

        sp_p1_rec = self.env['product.product'].search([('default_code','=','P1')])
        sp_p2_rec = self.env['product.product'].search([('default_code','=','P2')])
        sp_p3_rec = self.env['product.product'].search([('default_code','=','P3')])

        if sp_p1_rec!=0:
            new.service_product_ids.create({'product_id':sp_p1_rec.id,
                                            'sale_product_id':new.id})
        if sp_p2_rec!=0:
            new.service_product_ids.create({'product_id':sp_p2_rec.id,
                                            'sale_product_id':new.id})
        if sp_p3_rec!=0:
            new.service_product_ids.create({'product_id':sp_p3_rec.id,
                                            'sale_product_id':new.id})
