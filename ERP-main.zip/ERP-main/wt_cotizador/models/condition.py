# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Condition(models.Model):
    _name = 'condition.condition'
    _description = "Condition Details"

    name = fields.Char(string="Cond",required=True)
    description = fields.Char(string="Descripción")