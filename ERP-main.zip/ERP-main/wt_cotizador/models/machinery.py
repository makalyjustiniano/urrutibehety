# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class ProductCategory(models.Model):
	_name= "machinery.machinery"
	_description = "Machinery Details"

	name = fields.Char(string="Maquinaria",required=True)
	description = fields.Char(string="Descripción")