Apply global discounts to invoices
