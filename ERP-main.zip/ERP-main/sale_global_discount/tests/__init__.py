from . import test_sale_global_discount
