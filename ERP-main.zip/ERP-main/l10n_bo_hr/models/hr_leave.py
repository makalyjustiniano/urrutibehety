from odoo import models, fields, api
from .num_literal import to_word
from odoo.tools import float_compare, float_is_zero, plaintext2html
from dateutil.relativedelta import relativedelta



class HrLeave(models.Model):
    _inherit = 'hr.leave'

    company_id = fields.Many2one('res.company', readonly=False, default=lambda self: self.env.company, required=True)