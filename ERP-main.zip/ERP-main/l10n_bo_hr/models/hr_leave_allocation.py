from odoo import models, fields
from dateutil import relativedelta


class HrLeaveAllocation(models.Model):
    _inherit = 'hr.leave.allocation'

    def _hr_leave_update(self):
        contracts = self.env['hr.contract'].search([('state', '=', 'open')])
        fecha_actual = fields.Date.today()
        allocation_obj = self.env['hr.leave.allocation']
        for contract in contracts:
            # fecha_contrato = contract.date_start
            fecha_contrato = contract.employee_id.first_contract_date
            delta = relativedelta.relativedelta(fecha_actual, fecha_contrato)
            entry_type = self.env['hr.work.entry.type'].search([('code', '=', 'VAC01')])
            leave_type = self.env['hr.leave.type'].search([('work_entry_type_id', '=', entry_type[0].id)])
            # Verificar la ultima asignacion registrada
            allocation = allocation_obj.search([('date_to', '<', fecha_actual),
                                                ('employee_id', '=', contract.employee_id.id),
                                                ('holiday_status_id', '=', leave_type[0].id),
                                                ('state', '=', 'validate')])

            # Verificar si existe uno activo actual

            if allocation:
                leave = self.env['hr.leave'].search([('employee_id', '=', contract.employee_id.id),
                                                     ('request_date_from', '>=', fecha_contrato),
                                                     ('request_date_to', '<=', allocation[0].date_to),
                                                     ('state', '=', 'validate')
                                                     ])

                # Necesitamos validar si existe uno ya enfuncionamiento
                n_dias = 0
                for lea in leave:
                    n_dias += lea.number_of_days

                fecha_inicial = allocation[0].date_to + relativedelta.relativedelta(days=1)
                fecha_fin = fecha_inicial + relativedelta.relativedelta(years=1) - relativedelta.relativedelta(days=1)
                if 1 <= delta.years < 5:
                    # dias = 15 + diff
                    dias = 15
                elif 5 <= delta.years < 10:
                    # dias = 20 + diff
                    dias = 20
                elif delta.years >= 10:
                    # dias = 30 + diff
                    dias = 30
                else:
                    dias = 0

                allocation = allocation_obj.search([('date_to', '>', fecha_actual),
                                                    ('date_from', '<', fecha_actual),
                                                    ('employee_id', '=', contract.employee_id.id),
                                                    ('holiday_status_id', '=', leave_type[0].id),
                                                    ('state', '=', 'validate')])

                if dias > 0 and not allocation:
                    vals = {
                        'name': 'Vacaciones Empleado ' + contract.employee_id.name + ' (' + str(dias) + ') Dias',
                        'holiday_status_id': leave_type[0].id,
                        'employee_id': contract.employee_id.id,
                        'number_of_days': dias,
                        'state': 'draft',
                        'date_from': fecha_inicial,
                        'date_to': fecha_fin,
                    }
                    all = allocation_obj.create(vals)
                    if all.state == 'draft':
                        all.action_confirm()
                        all.action_validate()
                    # allocation[0].action_refuse()
