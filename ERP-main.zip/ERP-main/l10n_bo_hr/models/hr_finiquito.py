from odoo import models, fields, api, _, tools
from datetime import datetime
from datetime import date
from dateutil import relativedelta


class HrFiniquitoOther(models.Model):
    _name = "hr.finiquito.other"
    _description = "Otros Conceptos de Pago"

    finiquito_id = fields.Many2one('hr.finiquito', 'Finiquito', required=True, ondelete='cascade')
    name = fields.Char('Descripcion')
    first_amount = fields.Float('Primer Mes')
    second_amount = fields.Float('Segundo Mes')
    third_amount = fields.Float('Tercer Mes')
    amount_total = fields.Float('Monto Total', compute="_compute_amount_total")

    def _compute_amount_total(self):
        self.amount_total = (self.first_amount or 0.00) + (self.second_amount or 0.00) + (self.third_amount or 0.00)


class HrFiniquitoBenefit(models.Model):
    _name = 'hr.finiquito.benefit'
    _description = 'Calculo de Tiempos para los finiquitos'

    finiquito_id = fields.Many2one('hr.finiquito', 'Finiquito', required=True, ondelete='cascade')
    code = fields.Char(string="Codigo", required=True, default="Otros")
    name = fields.Char(string="Descripcion")
    gestion = fields.Integer(string="Gestion")
    tiempo = fields.Integer(string="Tiempo")
    medida = fields.Char(string="Medida")
    tiempo2 = fields.Integer(string="Tiempo_2")
    medida2 = fields.Char(string="Medida_2")
    monto = fields.Float(string="Monto")


class HrFiniquitoDeductions(models.Model):
    _name = 'hr.finiquito.deductions'
    _description = "Registro de Dedudciones"

    finiquito_id = fields.Many2one('hr.finiquito', 'Finiquito', required=True)
    code = fields.Char(string="Codigo")
    name = fields.Char(string="Descripcion")
    amount_total = fields.Float(string="Monto Total")
    advance_id = fields.Many2one('hr.advance', 'Adelanto', readonly=True)


class HrFiniquito(models.Model):
    _name = "hr.finiquito"
    _description = "Finiquito"
    _rec_name = "employee_id"

    @api.onchange('employee_id')
    def onchange_employee_id(self):
        if self.employee_id.contract_id:
            self.contract_id = self.employee_id.contract_id.id
            self.date_from = self.contract_id.date_start
            payslip_ids = self.env['hr.payslip'].search(
                [('employee_id', '=', self.employee_id.id), ('state', '=', 'done')], limit=3, order="date_from desc")
            for index, p in enumerate(payslip_ids):
                if index == 0:
                    self.payslip_third_id = p.id
                    self.payslip_second_id = False
                    self.payslip_one_id = False
                elif index == 1:
                    self.payslip_second_id = p.id
                    self.payslip_one_id = False
                elif index == 2:
                    self.payslip_one_id = p.id
            if not payslip_ids:
                self.payslip_third_id = False
                self.payslip_second_id = False
                self.payslip_one_id = False
        else:
            self.contract_id = False
            self.date_from = False
            self.payslip_third_id = False
            self.payslip_second_id = False
            self.payslip_one_id = False

    @api.onchange('payslip_one_id')
    def onchange_payslip_one_id(self):
        for s in self.payslip_one_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                lambda x: x.code == 'NET' or x.code == 'NETBO'):
            self.first_amount = s.total

    @api.onchange('payslip_second_id')
    def onchange_payslip_second_id(self):
        for s in self.payslip_second_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                lambda x: x.code == 'NET' or x.code == 'NETBO'):
            self.second_amount = s.total

    @api.onchange('payslip_third_id')
    def onchange_payslip_third_id(self):
        for s in self.payslip_third_id.mapped('line_ids').filtered(lambda line: line.category_id).filtered(
                lambda x: x.code == 'NET' or x.code == 'NETBO'):
            self.third_amount = s.total

    @api.onchange('date_to', 'date_from')
    def onchange_date_to(self):
        if self.date_from == False:
            return
        if self.date_to == False:
            return
        data_entrada = self.date_from
        data_salida = self.date_to
        delta = relativedelta.relativedelta(data_salida, data_entrada)
        self.years = delta.years
        self.months = delta.months
        self.days = delta.days + 1
        self.compute_vacaciones()

    company_id = fields.Many2one('res.company', string=u'Compañia', change_default=True,
                                 default=lambda self: self.env['res.company']._company_default_get('hr.finiquito'))

    date = fields.Date('Fecha', default=fields.Date.today(), required=True, states={'draft': [('readonly', False)]})

    employee_id = fields.Many2one('hr.employee', string="Empleado", required=True, readonly=True,
                                  states={'draft': [('readonly', False)]})
    contract_id = fields.Many2one('hr.contract', string="Contrato", readonly=True,
                                  states={'draft': [('readonly', False)]})
    date_from = fields.Date('fecha de entrada', required=True, readonly=True, states={'draft': [('readonly', False)]})
    date_to = fields.Date('fecha de salida', required=True, readonly=True, states={'draft': [('readonly', False)]})
    note = fields.Text('Motivo del Retiro', readonly=True, states={'draft': [('readonly', False)]})
    ouster = fields.Boolean(string="Desahucio(Retiro Forsozo)", readonly=True, states={'draft': [('readonly', False)]})
    ouster_amount = fields.Float('Desahucio', readonly=True, states={'draft': [('readonly', False)]})
    benefit_ids = fields.One2many('hr.finiquito.benefit', 'finiquito_id', 'Lineas de Tiempo', readonly=True,
                                  states={'draft': [('readonly', False)]})
    other_ids = fields.One2many('hr.finiquito.other', 'finiquito_id', "Parte b", readonly=True,
                                states={'draft': [('readonly', False)]})
    other_amount = fields.Float('Total Promedio Indemnizable', readonly=True, states={'draft': [('readonly', False)]})
    deductions_ids = fields.One2many('hr.finiquito.deductions', 'finiquito_id', "Deduciones", readonly=True,
                                     states={'draft': [('readonly', False)]})
    holidays_day = fields.Float('Vacacion(Dias)', readonly=True, states={'draft': [('readonly', False)]})
    holidays_month = fields.Float('Vacacion(Meses)', readonly=True, states={'draft': [('readonly', False)]})
    amount_benefit = fields.Float('Total Beneficios Sociales', readonly=True, states={'draft': [('readonly', False)]})
    amount_compensable = fields.Float(string="Total indemnizable", readonly=True,
                                      states={'draft': [('readonly', False)]})
    amount_deduction = fields.Float(string="Total Deduciones", readonly=True, states={'draft': [('readonly', False)]})
    amount_total_pay = fields.Float(string="Importe Liquido a Pagar", readonly=True,
                                    states={'draft': [('readonly', False)]})
    days = fields.Integer(string="Dias", readonly=True, states={'draft': [('readonly', False)]})
    months = fields.Integer(string="Meses", readonly=True, states={'draft': [('readonly', False)]})
    years = fields.Integer(string="Años", readonly=True, states={'draft': [('readonly', False)]})
    advance = fields.Boolean(string='Aplicar Adelanto')

    payslip_one_id = fields.Many2one('hr.payslip', 'Nomina Mes Primero')
    payslip_second_id = fields.Many2one('hr.payslip', 'Nomina Mes Segundo')
    payslip_third_id = fields.Many2one('hr.payslip', 'Nomina Mes Tercero')

    first_amount = fields.Float('Monto Mes Primero', required=True)
    second_amount = fields.Float('Monto Mes Segundo', required=True)
    third_amount = fields.Float('Monto Mes Tercero', required=True)

    amount_promedio = fields.Float('Proemdio Total', compute="_compute_amount_total")

    state = fields.Selection([
        ('draft', 'Borrador'),
        ('done', 'Confirmado'),
        ('cancel', 'Cancelado'),
    ], 'Status', readonly=True, default="draft")

    tipo = fields.Selection([
        ('fiscal', 'Fiscal'),
        ('interno', 'Interno')
    ], 'Tipo', default="fiscal")

    dbonus = fields.Boolean('Doble Aguinaldo', default=False)
    years_amount = fields.Float('Monto por Años', default=0)
    months_amount = fields.Float('Monto por Meses', default=0)
    days_amount = fields.Float('Monto por Dias', default=0)

    months_bonus = fields.Integer('Aguinaldo Meses', default=0)
    days_bonus = fields.Integer('Aguinaldo Dias', default=0)
    bonus_amount = fields.Float('Total Aguinaldo', default=0)

    def _compute_amount_total(self):
        self.amount_promedio = (self.first_amount or 0.00) + (self.second_amount or 0.00) + (self.third_amount or 0.00)

    def compute_vacaciones(self):
        entry_type = self.env['hr.work.entry.type'].search([('code', '=', 'VAC01')])
        leave_type = self.env['hr.leave.type'].search([('work_entry_type_id', '=', entry_type[0].id)])

        # Ultima asignacion de vacaciones
        allocation_ul = self.env['hr.leave.allocation'].search([('employee_id', '=', self.employee_id.id),
                                                                ('date_from', '<', self.date_to),
                                                                ('holiday_status_id', '=', leave_type[0].id),
                                                                ('state', '=', 'validate')], order="date_from desc",
                                                               limit=1)
        if allocation_ul:
            allocation = self.env['hr.leave.allocation'].search([('employee_id', '=', self.employee_id.id),
                                                                 ('date_from', '<', self.date_to),
                                                                 ('holiday_status_id', '=', leave_type[0].id),
                                                                 ('state', '=', 'validate'),
                                                                 ('id', '!=', allocation_ul[0].id)])
            n_dias_all = 0
            for all in allocation:
                n_dias_all += all.number_of_days
            days_total = (self.date_to - allocation_ul[0].date_from).days + 1
            leave_ul = self.env['hr.leave'].search([('employee_id', '=', self.employee_id.id),
                                                    ('request_date_to', '>=', allocation_ul[0].date_from),
                                                    ('request_date_from', '<=', self.date_to),
                                                    ('state', '=', 'validate')])
            dias_cons = 0
            for lv_ul in leave_ul:
                dias_cons += lv_ul.number_of_days
            dias_vac_ul = allocation_ul[0].number_of_days - dias_cons
            mult = (days_total * dias_vac_ul) / 365
            leave = self.env['hr.leave'].search([('employee_id', '=', self.employee_id.id),
                                                 ('request_date_to', '<=', allocation_ul[0].date_from),
                                                 ('state', '=', 'validate')])
            n_dias_leav = 0
            for lea in leave:
                n_dias_leav += lea.number_of_days

            self.holidays_day = (n_dias_all + round(mult, 2)) - n_dias_leav

    def compute_finiquito(self):
        promedio = sum(o.amount_total for o in self.other_ids) or 0.00
        promedio += self.amount_promedio
        promedio /= 3
        deductions = sum(d.amount_total for d in self.deductions_ids)
        self.years_amount = float(int(self.years)) * promedio
        self.months_amount = (float(self.months) / 12) * promedio
        self.days_amount = (float(self.days) / 360) * promedio
        aguinaldo_months = 0
        aguinaldo_days = 0
        aguinaldo_months_total = 0
        aguinaldo_days_total = 0
        self.benefit_ids.unlink()
        if self.years > 0:
            # data_entrada = date(date.today().year, 1, 1)
            data_entrada = date(self.date.year, 1, 1)
            data_entrada = datetime.combine(data_entrada, datetime.min.time())
            data_salida = datetime.strptime(str(self.date_to), '%Y-%m-%d')
            delta = relativedelta.relativedelta(data_salida, data_entrada)
            # dif = (data_salida - data_entrada).days
            # years = float(dif) / 360
            # aguinaldo_months = ((years - float(int(years))) * 360) / 30
            # aguinaldo_days = ((aguinaldo_months - float(int(aguinaldo_months))) * 30)
            aguinaldo_months = delta.months
            aguinaldo_days = delta.days + 1
            aguinaldo_months_total = (aguinaldo_months / 12) * promedio
            aguinaldo_days_total = (aguinaldo_days / 360) * promedio
            self.months_bonus = aguinaldo_months
            self.days_bonus = aguinaldo_days
            self.bonus_amount = aguinaldo_months_total + aguinaldo_days_total
            if self.dbonus:
                self.bonus_amount *= 2
            benefits = []
            total_vacacion = 0
            if self.years >= 1:
                if self.holidays_day > 0:
                    # if self.years <= 4:
                    #     a = 2
                    # if 4 < self.years <= 9:
                    #     a = 1.5
                    # if self.years > 9:
                    #     a = 1
                    pay_dia = promedio / 30

                    # total_vacacion = self.holidays_day / a / 360 * promedio
                    total_vacacion = pay_dia * self.holidays_day
                    benefits.append((0, 0, {'code': 'otros',
                                            'name': 'Vacacion',
                                            'tiempo': self.holidays_day,
                                            'medida': 'Dias',
                                            'monto': total_vacacion,
                                            'gestion': ''}))
                # if self.holidays_month > 0:
                #     if self.years <= 4:
                #         a = 2
                #     if 4 < self.years <= 9:
                #         a = 1.5
                #     if self.years > 9:
                #         a = 1
                #     total_vacacion = self.holidays_day / a / 12 * promedio
                #     benefits.append((0, 0, {'code': 'otros',
                #                             'name': 'Vacacion',
                #                             'tiempo': self.holidays_day,
                #                             'medida': 'Dias',
                #                             'monto': total_vacacion,
                #                             'gestion': ''}))
                total_s = self.years_amount + self.months_amount + self.days_amount + self.bonus_amount + total_vacacion
                importe_liquido = total_s - deductions
                self.other_amount = promedio
                if self.ouster:
                    self.ouster_amount = promedio * 3
                else:
                    self.ouster_amount = 0.00
                self.benefit_ids = benefits
                self.amount_benefit = total_s
                self.amount_deduction = deductions
                self.amount_total_pay = importe_liquido
            else:
                self.amount_benefit = 0
                self.amount_deduction = 0
                self.amount_total_pay = 0

        else:
            benefits = []
            total_vacacion = 0
            if self.months > 5:
                data_entrada = date(date.today().year, 1, 1)
                data_entrada = datetime.combine(data_entrada, datetime.min.time())
                data_salida = datetime.strptime(str(self.date_to), '%Y-%m-%d')
                delta = relativedelta.relativedelta(data_salida, data_entrada)
                # dif = (data_salida - data_entrada).days
                # years = float(dif) / 360
                # aguinaldo_months = ((years - float(int(years))) * 360) / 30
                # aguinaldo_days = ((aguinaldo_months - float(int(aguinaldo_months))) * 30)
                aguinaldo_months = delta.months
                aguinaldo_days = delta.days + 1
                aguinaldo_months_total = (aguinaldo_months / 12) * promedio
                aguinaldo_days_total = (aguinaldo_days / 360) * promedio
                self.months_bonus = aguinaldo_months
                self.days_bonus = aguinaldo_days
                self.bonus_amount = aguinaldo_months_total + aguinaldo_days_total
                if self.dbonus:
                    self.bonus_amount *= 2
            if self.months >= 6:
                if self.holidays_day > 0:
                    # if self.years <= 4:
                    #     a = 2
                    # if 4 < self.years <= 9:
                    #     a = 1.5
                    # if self.years > 9:
                    #     a = 1
                    total_dia = ((self.months * 30 + self.days) * self.holidays_day) / 360

                    # total_vacacion = self.holidays_day / total_dia / 360 * promedio
                    total_vacacion = (promedio / 30) * total_dia
                    benefits.append((0, 0, {'code': 'otros',
                                            'name': 'Vacacion',
                                            'tiempo': self.holidays_day,
                                            'medida': 'Dias',
                                            'monto': total_vacacion,
                                            'gestion': ''}))
                if self.holidays_month > 0:
                    if self.years <= 4:
                        a = 2
                    if 4 < self.years <= 9:
                        a = 1.5
                    if self.years > 9:
                        a = 1
                    total_vacacion = self.holidays_day / a / 12 * promedio
                    benefits.append((0, 0, {'code': 'otros',
                                            'name': 'Vacacion',
                                            'tiempo': self.holidays_day,
                                            'medida': 'Dias',
                                            'monto': total_vacacion,
                                            'gestion': ''}))
                total_s = self.years_amount + self.months_amount + self.days_amount + self.bonus_amount + total_vacacion
                importe_liquido = total_s - deductions
                self.other_amount = promedio
                if self.ouster:
                    self.ouster_amount = promedio * 3
                else:
                    self.ouster_amount = 0.00
                self.benefit_ids = benefits
                self.amount_benefit = total_s
                self.amount_deduction = deductions
                self.amount_total_pay = importe_liquido
            else:
                self.amount_benefit = 0
                self.amount_deduction = 0
                self.amount_total_pay = 0

    def cancel_finiquito(self):
        self.contract_id.date_end = False
        self.contract_id.state = 'open'
        self.state = 'cancel'

    def done_finiquito(self):
        # self.calcular_finiquito()
        self.contract_id.date_end = self.date_to
        self.contract_id.state = 'close'
        self.state = 'done'
