from odoo import fields, models, api, _


class HrRetroactivoData(models.Model):
    _name = 'hr.retroactivo.data'

    def _get_years(self):
        return [(str(i), i) for i in range(fields.Date.today().year, 2009, -1)]

    name = fields.Selection(
        selection='_get_years', string='Gestión', required=True,
        default=lambda x: str(fields.Date.today().year - 1))
    percen_bas = fields.Float(string='Porcentaje Haber Basico', digits=[12, 12])
    percen_min = fields.Float(string='Porcentaje Haber Mínimo', digits=[12, 12])
