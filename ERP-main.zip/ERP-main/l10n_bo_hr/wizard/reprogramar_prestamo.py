# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime


class ReprogramarPrestamo(models.TransientModel):
    _name = "reprogramar.prestamo"
    _description = "Reprogramación de Prestamos"

    date_init = fields.Date(string='Fecha Inicial Prestamo')
    amount = fields.Float(string='Monto Reprogramar', help='Puede incrementar o dejar como esta')
    time_pay = fields.Integer('Coutas de Pago', help="Puede determinar una cantidad de cuotas diferente")

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        prestamo_id = self.env['hr.prestamos'].browse(self.env.context.get('active_id'))
        line_prestamo = self.env['hr.prestamos.line'].search(
            [('prestamos_id', '=', prestamo_id.id), ('state', '=', 'process')], limit=1, order='date asc')

        line_prestamo_done = self.env['hr.prestamos.line'].search(
            [('prestamos_id', '=', prestamo_id.id), ('state', '=', 'done')])

        if line_prestamo:
            res['date_init'] = line_prestamo.date
        res['amount'] = prestamo_id.amount - prestamo_id.amount_paid
        res['time_pay'] = prestamo_id.time_pay - len(line_prestamo_done)
        return res

    def reprogramar_prestamo(self):
        prestamos = self.env['hr.prestamos'].browse(self._context.get('active_ids', []))
        for prestamo in prestamos:
            line_prestamo = self.env['hr.prestamos.line'].search(
                [('prestamos_id', '=', prestamo.id), ('state', '=', 'process')])
            line_prestamo.unlink()
            prestamo.date_start = self.date_init
            prestamo.amount = self.amount
            prestamo.time_pay = self.time_pay
            prestamo.calcular_prestamos()
            line_prestamo_confirm = self.env['hr.prestamos.line'].search(
                [('prestamos_id', '=', prestamo.id), ('state', '=', 'draft')])
            for ln in line_prestamo_confirm:
                ln.state = 'process'
