# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime
from odoo.tools import float_is_zero


class AdelantarPrestamo(models.TransientModel):
    _name = "adelantar.prestamo"
    _description = "Adelantar de Prestamos"

    line_ids = fields.One2many('adelantar.prestamo.line', 'wizard_id', string='Lineas')
    amount_total = fields.Float(string='Total', compute="_compute_total", )

    @api.depends('line_ids.confirm')
    def _compute_total(self):
        for s in self:
            total = 0
            for line in s.line_ids:
                if line.confirm:
                    total += line.amount
            s.amount_total = total

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        prestamo_id = self.env['hr.prestamos'].browse(self.env.context.get('active_id'))
        line_prestamo = self.env['hr.prestamos.line'].search(
            [('prestamos_id', '=', prestamo_id.id), ('state', '=', 'process')], order='date asc')
        line_ids = []
        for line in line_prestamo:
            val = (0, 0, {
                'line_id': line.id,
                'amount': line.amount,
            })
            line_ids.append(val)
        res['line_ids'] = line_ids
        return res

    def adelantar_prestamo(self):
        prestamos = self.env['hr.prestamos'].browse(self._context.get('active_ids', []))
        move_pool = self.env['account.move']
        for prestamo in prestamos:
            for line in self.line_ids:
                if line.confirm:
                    line.line_id.state = 'done'
            date = fields.Date.today()
            line_ids = []
            default_partner_id = prestamo.employee_id.address_home_id.id
            name = _('Adelanto del prestamo para %s') % (prestamo.employee_id.name)
            move = {
                'narration': name,
                'date': date,
                'ref': prestamo.name,
                'journal_id': prestamo.journal_id.id,
            }
            amt = self.amount_total
            if float_is_zero(amt, precision_digits=2):
                continue
            partner_id = default_partner_id
            debit_account_id = prestamo.account_credit.id
            credit_account_id = prestamo.account_debit.id

            if debit_account_id:
                debit_line = (0, 0, {
                    'name': prestamos.name,
                    'date': date,
                    'partner_id': partner_id or False,
                    'account_id': debit_account_id,
                    'journal_id': prestamos.journal_id.id,
                    'debit': amt > 0.0 and amt or 0.0,
                    'credit': amt < 0.0 and -amt or 0.0,
                    # 'analytic_account_id': prestamos.analytic_account_id and prestamos.analytic_account_id.id or False,
                })
                line_ids.append(debit_line)

            if credit_account_id:
                credit_line = (0, 0, {
                    'name': prestamos.name,
                    'date': date,
                    'partner_id': partner_id or False,
                    'account_id': credit_account_id,
                    'journal_id': prestamos.journal_id.id,
                    'debit': amt < 0.0 and -amt or 0.0,
                    'credit': amt > 0.0 and amt or 0.0,
                    # 'analytic_account_id': prestamos.analytic_account_id and prestamos.analytic_account_id.id or False,
                })
                line_ids.append(credit_line)
            move.update({'line_ids': line_ids})
            move_id = move_pool.create(move)
            move_id.post()


class AdelantarPrestamoLine(models.TransientModel):
    _name = "adelantar.prestamo.line"
    _description = "Lineas Adelantar Prestamo"

    wizard_id = fields.Many2one('adelantar.prestamo', string='Adelantar Prestamo')
    line_id = fields.Many2one('hr.prestamos.line', string='Linea Adelanto')
    amount = fields.Float(string='Monto Prestamo')
    confirm = fields.Boolean(string='Adelantar')
