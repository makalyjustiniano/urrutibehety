# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = "product.template"

    sale_assets = fields.Many2one('account.asset', 'Ingreso diferido',
                                  domain="[('asset_type','=','sale'),('state','=','model')]")
    expense_assets = fields.Many2one('account.asset', 'Gastos diferido',
                                     domain="[('asset_type','=','expense'),('state','=','model')]")
