# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = "sale.order"

    journal_payment_auto = fields.Many2one('account.journal', 'Diario de pago',
                                           domain=[('type', 'in', ('bank', 'cash'))])

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        for rec in self:
            subscription_id = False
            template = False
            for line in rec.order_line:
                if line.subscription_id and line.subscription_id.id != subscription_id and line.subscription_id.template_id.id != template:
                    subscription_id = line.subscription_id.id
                    template = line.subscription_id.template_id.id
                    line.subscription_id.write({
                        'journal_payment_auto': rec.journal_payment_auto.id,
                        'sale_assets': line.product_id.sale_assets.id,
                        'expense_assets': line.product_id.expense_assets.id
                    })
            if subscription_id:
                result = rec._create_invoices()
                result.write({
                    'journal_payment_auto': rec.journal_payment_auto.id,
                })
                result.action_post()
        return res
