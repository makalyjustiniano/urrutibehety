# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Subscription(models.Model):
    _inherit = "sale.subscription"

    sale_assets = fields.Many2one('account.asset', 'Ingreso diferido',
                                  domain="[('asset_type','=','sale'),('state','=','model')]")
    expense_assets = fields.Many2one('account.asset', 'Gastos diferido',
                                     domain="[('asset_type','=','expense'),('state','=','model')]")
    journal_payment_auto = fields.Many2one('account.journal', 'Diario de pago',
                                           domain=[('type', 'in', ('bank', 'cash'))])

    def start_subscription(self):
        res = super(Subscription, self).start_subscription()
        self.generate_recurring_invoice()
        return res

