from odoo import api, models, fields


class AccountMove(models.Model):
    _inherit = "account.move"

    journal_payment_auto = fields.Many2one('account.journal', 'Diario de pago',
                                           domain=[('type', 'in', ('bank', 'cash'))])

    def _post(self, soft=True):
        journal_id = False
        for rec in self:
            if rec.invoice_line_ids:
                for lines in rec.invoice_line_ids:
                    if lines.subscription_id:
                        subscription_id = lines.subscription_id
                        template = subscription_id.template_id
                        if lines.product_id and (
                                (template.recurring_interval > 30 and template.recurring_rule_type == 'daily') or (
                                template.recurring_interval > 2 and template.recurring_rule_type == 'weekly') or (
                                        template.recurring_interval > 1 and template.recurring_rule_type == 'monthly') or template.recurring_rule_type == 'yearly'):
                            lines.write({'account_id': lines.subscription_id.sale_assets.account_depreciation_id.id,
                                         'account_root_id': lines.subscription_id.sale_assets.account_depreciation_id.root_id.id})
            subscription_id = False
            lines_account = []
            journal = False
            subscription_count = 0
            for lines in sorted(rec.invoice_line_ids, key=lambda x: x.subscription_id.id):
                if lines.subscription_id and (
                        (
                                lines.subscription_id.template_id.recurring_interval > 30 and lines.subscription_id.template_id.recurring_rule_type == 'daily') or (
                                lines.subscription_id.template_id.recurring_interval > 2 and lines.subscription_id.template_id.recurring_rule_type == 'weekly') or (
                                lines.subscription_id.template_id.recurring_interval > 1 and lines.subscription_id.template_id.recurring_rule_type == 'monthly') or lines.subscription_id.template_id.recurring_rule_type == 'yearly'):
                    journal = lines.subscription_id.journal_payment_auto.id
                    if lines.subscription_id.id != subscription_id:
                        subscription_count = 0
                        subscription_id = lines.subscription_id.id
                        lines_account = []
                        for count in rec.invoice_line_ids:
                            if count.id == subscription_id:
                                subscription_count += 1
                    for account in rec.line_ids:
                        if account.account_id.id == lines.subscription_id.expense_assets.account_depreciation_id.id and account.name == lines.name:
                            lines_account.append(account.id)

                    if lines_account and subscription_count == len(lines_account):
                        if subscription_id.expense_assets.account_depreciation_id.create_asset != 'no' and subscription_id.expense_assets.id == subscription_id.expense_assets.account_depreciation_id.asset_model.id:
                            expenses = self.env['account.asset'].create({
                                'picking_type_id': subscription_id.expense_assets.picking_type_id.id,
                                'name': 'Gasto diferido - Factura ' + rec.name,
                                'original_move_line_ids': [(4, account_line) for account_line in lines],
                                'method_period': subscription_id.expense_assets.method_period,
                                'method_number': subscription_id.expense_assets.method_number,
                                'prorata': False,
                                'account_depreciation_id': subscription_id.expense_assets.account_depreciation_id.id,
                                'account_depreciation_expense_id': subscription_id.expense_assets.account_depreciation_expense_id.id,
                            })
                            if subscription_id.expense_assets.account_depreciation_id.create_asset == 'validate':
                                expenses.compute_depreciation_board()
                                expenses.validate()
            if rec.journal_payment_auto:
                journal_id = rec.journal_payment_auto.id
            elif journal:
                journal_id = journal

        res = super(AccountMove, self)._post(soft)
        if journal_id:
            payment = self.env['account.payment.register'].with_context(active_ids=rec.ids,
                                                                        active_model='account.move',
                                                                        active_id=rec.id,
                                                                        journal_id=journal_id, ).create(
                {
                    'payment_type': 'inbound',
                    'partner_type': 'customer',
                    'partner_id': rec.partner_id.id,
                    'journal_id': journal_id,
                    'amount': rec.amount_total,
                    'currency_id': rec.currency_id.id,
                    'payment_date': rec.invoice_date,
                    'communication': rec.name,
                })
            payment.action_create_payments()
        return res

    def action_post(self):
        subscription_id = False
        for lines in self.invoice_line_ids:
            if lines.subscription_id:
                subscription_id = lines.subscription_id
        if subscription_id:
            return self._post()
        else:
            return super(AccountMove, self).action_post()
