# -*- coding: utf-8 -*-
{
    'name': "Account subscription",
    'description':
        """
        Integrate improved handling of deferred revenues and deferred expenses with subscriptions
        """,
    'author': "PROINTEC",
    'website': "http://www.prointeccr.com",
    'category': 'Extra Tools',
    'version': '15.0',
    'depends': ['base', 'sale', 'account', 'sale_subscription', 'account_accountant'],
    'data': [
        'views/sale_subscription_views.xml',
        'views/sale_order_views.xml',
        'views/product_template_views.xml'
    ],

}
