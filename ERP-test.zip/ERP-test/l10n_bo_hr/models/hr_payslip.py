from odoo import models, fields, api
from .num_literal import to_word
from odoo.tools import float_compare, float_is_zero, plaintext2html
from dateutil.relativedelta import relativedelta


class HrPayslipInputMassive(models.Model):
    _name = 'hr.payslip.input.massive'
    _description = 'Lineas'
    _order = 'employee_id, date_start'

    name = fields.Char(string='Descripción', required=True)
    input_type_id = fields.Many2one('hr.payslip.input.type', string='Tipo entrada', required=True)
    employee_id = fields.Many2one('hr.employee', 'Empleado', required=True)
    date_start = fields.Date(string='Desde', required=True)
    date_stop = fields.Date(string='Hasta', required=True)
    amount = fields.Float(string="Monto Aplicado")
    active_line = fields.Boolean(string='Activo')
    company_id = fields.Many2one('res.company', readonly=False, default=lambda self: self.env.company, required=True)


class HrPayslipAnalytic(models.Model):
    _name = 'hr.payslip.analytic'
    _description = 'Lineas centros de costo analticaa'

    name = fields.Char('Linea')
    employee_id = fields.Many2one('hr.employee', 'Empleado')
    contract_id = fields.Many2one('hr.contract', 'Contrato')
    company_id = fields.Many2one('res.company', string='Compañia', required=True, readonly=True,
                                 default=lambda self: self.env.company)
    analytic_account_id = fields.Many2one('account.analytic.account', 'Cuenta Analítica',
                                          domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    date = fields.Date('Fecha Registro')
    date_start = fields.Datetime(required=True, string='Desde')
    date_stop = fields.Datetime(compute='_compute_date_stop', store=True, readonly=False, string='Hasta')
    duration = fields.Float(compute='_compute_duration', store=True, string="Horas")

    @api.depends('date_start', 'duration')
    def _compute_date_stop(self):
        for work_entry in self.filtered(lambda w: w.date_start and w.duration):
            work_entry.date_stop = work_entry.date_start + relativedelta(hours=work_entry.duration)
            work_entry.date = work_entry.date_start

    @api.depends('date_stop', 'date_start')
    def _compute_duration(self):
        for work_entry in self:
            work_entry.duration = work_entry._get_duration(work_entry.date_start, work_entry.date_stop)

    def _get_duration(self, date_start, date_stop):
        if not date_start or not date_stop:
            return 0
        dt = date_stop - date_start
        return dt.days * 24 + dt.seconds / 3600  # Number of hours


class Payslip(models.Model):
    _inherit = 'hr.payslip'

    porcen_basico = fields.Float(string='Porcentaje haber básico', digits=(12, 4),
                                 help='Cuando se establece una planilla de retroactivo')
    porcen_minimo = fields.Float(string='Porcentaje haber mínimo', digits=(12, 4),
                                 help='Cuando se establece una planilla de retroactivo')

    def _compute_basic_net(self):
        line_values = (self._origin)._get_line_values(['BASIC', 'NET', 'BASICBO', 'NETBO'])
        for payslip in self:
            payslip.basic_wage = line_values['BASIC'][payslip._origin.id]['total']
            payslip.net_wage = line_values['NET'][payslip._origin.id]['total']
            if payslip.basic_wage <= 0:
                payslip.basic_wage = line_values['BASICBO'][payslip._origin.id]['total']

            if payslip.net_wage <= 0:
                payslip.net_wage = line_values['NETBO'][payslip._origin.id]['total']

    def print_report(self):
        return self.env.ref('l10n_bo_hr.graphic_representation').report_action(self)

    def compute_sheet(self):
        for pay in self:
            adelantos = self.env['hr.adelantos']
            prestamos = self.env['hr.prestamos.line']
            input_pay = self.env['hr.payslip.input']

            for i in adelantos.search(
                    [('contract_id', '=', pay.contract_id.id),
                     ('state', '=', 'process'),
                     ('date', '>=', pay.date_from),
                     ('date', '<=', pay.date_to)]):
                if i.input_type_id:
                    type_pres = self.env['hr.adelantos.inputs'].search([
                        ('contract_id', '=', pay.contract_id.id),
                        ('employee_id', '=', pay.employee_id.id),
                        ('date', '>=', pay.date_from),
                        ('date', '<=', pay.date_to),
                        ('input_type_id', '=', i.input_type_id.id)
                    ])
                    if type_pres:
                        type_a_id = type_pres[0].input_type_id.id
                    else:
                        type_pres = self.env['hr.adelantos.inputs'].search([
                            ('contract_id', '=', pay.contract_id.id),
                            ('employee_id', '=', pay.employee_id.id),
                            ('date', '>=', pay.date_from),
                            ('date', '<=', pay.date_to)
                        ])
                        if type_pres:
                            type_a_id = type_pres[0].input_type_id.id
                        else:
                            type_a_id = self.env.ref('l10n_bo_hr.input_bo_adelanto').id
                    unlink_input = input_pay.search([('input_type_id', '=', type_a_id), ('payslip_id', '=', pay.id)])
                    if unlink_input:
                        unlink_input.unlink()

                else:
                    type_a_id = self.env.ref('l10n_bo_hr.input_bo_adelanto').id
                    unlink_input = input_pay.search([('input_type_id', '=', type_a_id), ('payslip_id', '=', pay.id)])
                    if unlink_input:
                        unlink_input.unlink()

                input = {
                    'name': i.name,
                    'amount': i.amount,
                    'payslip_id': pay.id,
                    'input_type_id': type_a_id,
                }
                input_pay.create(input)

            for a in prestamos.search(
                    [('prestamos_id.contract_id', '=', pay.contract_id.id),
                     ('state', '=', 'process'),
                     ('date', '>=', pay.date_from),
                     ('date', '<=', pay.date_to)]):
                if a.prestamos_id.input_type_id:
                    type_pres = self.env['hr.prestamos.inputs'].search([
                        ('contract_id', '=', pay.contract_id.id),
                        ('employee_id', '=', pay.employee_id.id),
                        ('date', '>=', pay.date_from),
                        ('date', '<=', pay.date_to),
                        ('input_type_id', '=', a.prestamos_id.input_type_id.id)
                    ])

                    if type_pres:
                        type_p_id = type_pres[0].input_type_id.id
                    else:
                        type_pres = self.env['hr.prestamos.inputs'].search([
                            ('contract_id', '=', pay.contract_id.id),
                            ('employee_id', '=', pay.employee_id.id),
                            ('date', '>=', pay.date_from),
                            ('date', '<=', pay.date_to)
                        ])
                        if type_pres:
                            type_p_id = type_pres[0].input_type_id.id
                        else:
                            type_p_id = self.env.ref('l10n_bo_hr.input_bo_prestamo').id

                    unlink_input = input_pay.search([('input_type_id', '=', type_p_id), ('payslip_id', '=', pay.id)])
                    if unlink_input:
                        unlink_input.unlink()
                else:
                    type_p_id = self.env.ref('l10n_bo_hr.input_bo_prestamo').id
                    unlink_input = input_pay.search([('input_type_id', '=', type_p_id), ('payslip_id', '=', pay.id)])
                    if unlink_input:
                        unlink_input.unlink()

                input = {
                    'name': a.name,
                    'amount': a.amount_total_pay,
                    'payslip_id': pay.id,
                    'input_type_id': type_p_id,
                }
                input_pay.create(input)

            # Buscar todos los inputs masivos
            type_pres = self.env['hr.payslip.input.massive'].search([
                ('employee_id', '=', pay.employee_id.id),
                ('date_start', '<=', pay.date_from),
                ('date_stop', '>=', pay.date_to),
                ('active_line', '=', True)])

            for type_pre in type_pres:
                unlink_input = input_pay.search(
                    [('input_type_id', '=', type_pre.input_type_id.id), ('payslip_id', '=', pay.id)])
                if unlink_input:
                    unlink_input.unlink()
                input = {
                    'name': type_pre.name,
                    'amount': type_pre.amount,
                    'payslip_id': pay.id,
                    'input_type_id': type_pre.input_type_id.id,
                }
                input_pay.create(input)

        return super().compute_sheet()

    def _get_base_local_dict(self):
        res = super()._get_base_local_dict()
        res.update({
            'calculo_bono_antiguedad': calculo_bono_antiguedad,
            'calculo_bono_antiguedad_anterior': calculo_bono_antiguedad_anterior,
            'calculo_horas_extra': calculo_horas_extra,
            'calculo_horas_extra_domingo': calculo_horas_extra_domingo,
            'calculo_horas_recargo_nocturno': calculo_horas_recargo_nocturno,
            'calculo_otros_bonos': calculo_otros_bonos,
            'calculo_rciva': calculo_rciva,
            'importe_rciva': importe_rciva,
            'basico_anterior_min': basico_anterior_min,
            'basico_anterior_max': basico_anterior_max,
        })
        return res

    def amount_literal(self, payslip):
        pays_line = self.env['hr.payslip.line'].search([('slip_id', '=', payslip.id), ('code', '=', 'NETBO')])
        total = 0
        if pays_line:
            for pay_line in pays_line:
                total += pay_line.total
        letras = ''
        if total > 0:
            texto = to_word(total) + ' BOLIVIANOS'
            letras = str(texto).upper()
        return letras

    def neto_pagar(self, payslip):
        pays_line = self.env['hr.payslip.line'].search([('slip_id', '=', payslip.id), ('code', '=', 'NETBO')])
        total = 0
        if pays_line:
            for pay_line in pays_line:
                total += pay_line.total
        return total

    def action_payslip_cancel(self):
        adelantos = self.env['hr.adelantos']
        prestamos = self.env['hr.prestamos.line']
        for pay in self:
            for i in adelantos.search(
                    [('contract_id', '=', pay.contract_id.id),
                     ('state', '=', 'done'),
                     ('date', '>=', pay.date_from),
                     ('date', '<=', pay.date_to)]):
                i.state = 'process'
            for a in prestamos.search(
                    [('prestamos_id.contract_id', '=', pay.contract_id.id),
                     ('state', '=', 'done'),
                     ('date', '>=', pay.date_from),
                     ('date', '<=', pay.date_to)]):
                a.state = 'process'
        return super(Payslip, self).action_payslip_cancel()

    def action_payslip_done(self):
        """
            Generate the accounting entries related to the selected payslips
            A move is created for each journal and for each month.
        """
        adelantos = self.env['hr.adelantos']
        prestamos = self.env['hr.prestamos.line']
        res = super(Payslip, self).action_payslip_done()
        for pay in self:
            for i in adelantos.search(
                    [('contract_id', '=', pay.contract_id.id), ('state', '=', 'process'), ('date', '>=', pay.date_from),
                     ('date', '<=', pay.date_to)]):
                i.state = 'done'
            for a in prestamos.search(
                    [('prestamos_id.contract_id', '=', pay.contract_id.id),
                     ('state', '=', 'process'),
                     ('date', '>=', pay.date_from),
                     ('date', '<=', pay.date_to)]):
                a.state = 'done'
        return res

    def _prepare_slip_lines(self, date, line_ids):
        self.ensure_one()
        precision = self.env['decimal.precision'].precision_get('Payroll')
        new_lines = []
        d1 = self.date_to
        d2 = self.date_from
        # Total de dias de la planilla
        days_total = (d1 - d2).days + 1
        for line in self.line_ids.filtered(lambda line: line.category_id):
            amount = -line.total if self.credit_note else line.total
            if line.code == 'NET' or line.code == 'NETBO':  # Check if the line is the 'Net Salary'.
                for tmp_line in self.line_ids.filtered(lambda line: line.category_id):
                    if tmp_line.salary_rule_id.not_computed_in_net:  # Check if the rule must be computed in the 'Net Salary' or not.
                        if amount > 0:
                            amount -= abs(tmp_line.total)
                        elif amount < 0:
                            amount += abs(tmp_line.total)
            if float_is_zero(amount, precision_digits=precision):
                continue
            debit_account_id = line.salary_rule_id.account_debit.id
            credit_account_id = line.salary_rule_id.account_credit.id

            if debit_account_id:  # If the rule has a debit account.
                debit = amount if amount > 0.0 else 0.0
                credit = -amount if amount < 0.0 else 0.0

                debit_line = self._get_existing_lines(line_ids + new_lines, line, debit_account_id, debit, credit)
                if not debit_line:
                    # query = """select *, horas / 8 as dia
                    #             from (
                    #                      select t0.employee_id,
                    #                             t0.contract_id,
                    #                             t0.analytic_account_id,
                    #                             count(date)          as dias,
                    #                             sum(round(duration)) as horas
                    #                      from hr_payslip_analytic t0
                    #                      where t0.date between '2022-01-01' and '2022-01-31'
                    #                        and t0.employee_id = 6
                    #                        and t0.contract_id = 49
                    #                      group by t0.employee_id,
                    #                               t0.contract_id,
                    #                               t0.analytic_account_id
                    #                  ) as foo"""
                    # params = (d2, d1, self.employee_id.id, self.contract_id.id)
                    # self.env.cr.execute(query, params)
                    # d_tot = days_total
                    # result = self.env.cr.dictfetchall()
                    percent = 100
                    if self.employee_id.analytic_ids:
                        for lines in self.employee_id.analytic_ids:
                            # debit1 = debit * (lines['dia'] / days_total)
                            # credit1 = credit * (lines['dia'] / days_total)
                            debit1 = debit * lines.percent / 100
                            credit1 = credit * lines.percent / 100
                            percent -= lines.percent
                            # d_tot = d_tot - lines['dia']

                            debit_line = self._prepare_line_values(line, debit_account_id, date, debit1, credit1,
                                                                   account_analytic_id=lines.analytic_account_id.id)
                            debit_line['tax_ids'] = [(4, tax_id) for tax_id in
                                                     line.salary_rule_id.account_debit.tax_ids.ids]
                            new_lines.append(debit_line)
                        if percent > 0:
                            debit1 = debit * percent / 100
                            credit1 = credit * percent / 100
                            debit_line = self._prepare_line_values(line, debit_account_id, date, debit1, credit1,
                                                                   account_analytic_id=False)
                            debit_line['tax_ids'] = [(4, tax_id) for tax_id in
                                                     line.salary_rule_id.account_debit.tax_ids.ids]
                            new_lines.append(debit_line)

                    else:
                        debit_line = self._prepare_line_values(line, debit_account_id, date, debit, credit)
                        debit_line['tax_ids'] = [(4, tax_id) for tax_id in
                                                 line.salary_rule_id.account_debit.tax_ids.ids]
                        new_lines.append(debit_line)

                else:
                    debit_line['debit'] += debit
                    debit_line['credit'] += credit

            if credit_account_id:  # If the rule has a credit account.
                debit = -amount if amount < 0.0 else 0.0
                credit = amount if amount > 0.0 else 0.0

                credit_line = self._get_existing_lines(line_ids + new_lines, line, credit_account_id, debit, credit)
                if not credit_line:
                    # query = """select *, horas / 8 as dia
                    #             from (
                    #                      select t0.employee_id,
                    #                             t0.contract_id,
                    #                             t0.analytic_account_id,
                    #                             count(date)          as dias,
                    #                             sum(round(duration)) as horas
                    #                      from hr_payslip_analytic t0
                    #                      where t0.date between '2022-01-01' and '2022-01-31'
                    #                        and t0.employee_id = 6
                    #                        and t0.contract_id = 49
                    #                      group by t0.employee_id,
                    #                               t0.contract_id,
                    #                               t0.analytic_account_id
                    #                  ) as foo"""
                    # params = (d2, d1, self.employee_id.id, self.contract_id.id)
                    # self.env.cr.execute(query, params)
                    # d_tot = days_total
                    # result = self.env.cr.dictfetchall()
                    percent = 100
                    if self.employee_id.analytic_ids:
                        for lines in self.employee_id.analytic_ids:
                            debit1 = debit * lines.percent / 100
                            credit1 = credit * lines.percent / 100
                            percent -= lines.percent
                            credit_line = self._prepare_line_values(line, credit_account_id, date, debit1, credit1,
                                                                    account_analytic_id=lines.analytic_account_id.id)
                            credit_line['tax_ids'] = [(4, tax_id) for tax_id in
                                                      line.salary_rule_id.account_credit.tax_ids.ids]
                            new_lines.append(credit_line)
                        if percent > 0:
                            debit1 = debit * percent / 100
                            credit1 = credit * percent / 100
                            credit_line = self._prepare_line_values(line, credit_account_id, date, debit1, credit1,
                                                                    account_analytic_id=False)
                            credit_line['tax_ids'] = [(4, tax_id) for tax_id in
                                                      line.salary_rule_id.account_credit.tax_ids.ids]
                            new_lines.append(credit_line)
                    else:
                        credit_line = self._prepare_line_values(line, credit_account_id, date, debit, credit)
                        credit_line['tax_ids'] = [(4, tax_id) for tax_id in
                                                  line.salary_rule_id.account_credit.tax_ids.ids]
                        new_lines.append(credit_line)

                else:
                    credit_line['debit'] += debit
                    credit_line['credit'] += credit
        return new_lines

    def _prepare_line_values(self, line, account_id, date, debit, credit, account_analytic_id=False):
        return {
            'name': line.name,
            'partner_id': line.partner_id.id,
            'account_id': account_id,
            'journal_id': line.slip_id.struct_id.journal_id.id,
            'date': date,
            'debit': debit,
            'credit': credit,
            'analytic_account_id': account_analytic_id or line.salary_rule_id.analytic_account_id.id or line.slip_id.contract_id.analytic_account_id.id,
        }


# Funciones adicionales calculo HHRR Bolivia
def calculo_bono_antiguedad(payslip):
    contract = payslip.contract_id
    bono = payslip.dict.env['hr.bono.antiguedad']
    start = contract.date_start
    end = payslip.date_to
    number_of_month = (end.year - start.year) * 12 + (end.month - start.month) + 1
    year = round(number_of_month / 12, 2)
    busqueda_bono = bono.search([('anio_min', '<=', year), ('anio_max', '>', year)])
    monto_bono = 0
    if busqueda_bono:
        monto_bono = (contract.company_id.sueldo_min * 3) * (busqueda_bono[0].porcentaje / 100)
    return monto_bono


# Funciones adicionales calculo HHRR Bolivia
def calculo_bono_antiguedad_anterior(payslip):
    contract = payslip.contract_id
    bono = payslip.dict.env['hr.bono.antiguedad']
    start = contract.date_start
    end = payslip.date_to
    number_of_month = (end.year - start.year) * 12 + (end.month - start.month) + 1
    year = round(number_of_month / 12, 2)
    busqueda_bono = bono.search([('anio_min', '<=', year), ('anio_max', '>', year)])
    monto_bono = 0
    if busqueda_bono:
        monto_bono = (contract.company_id.sueldo_min_ant * 3) * (busqueda_bono[0].porcentaje / 100)
    return monto_bono


def calculo_horas_extra(payslip):
    contract = payslip.contract_id
    horas = payslip.dict.env['hr.horas.extra']
    start = payslip.date_from
    end = payslip.date_to
    horas_extra = horas.search(
        [('date', '<=', end),
         ('date', '>=', start),
         ('employee_id', '=', contract.employee_id.id),
         ('type', '=', 'normal'),
         ('state', '=', 'validate')])
    tot_horas = 0
    for hr_ex in horas_extra:
        tot_horas += hr_ex.hour
    monto_dia = contract.wage / 30
    monto_hora = (monto_dia / 8) * 2
    monto_bono = monto_hora * tot_horas
    return monto_bono


def calculo_horas_extra_domingo(payslip):
    contract = payslip.contract_id
    horas = payslip.dict.env['hr.horas.extra']
    start = payslip.date_from
    end = payslip.date_to
    horas_extra = horas.search(
        [('date', '<=', end),
         ('date', '>=', start),
         ('employee_id', '=', contract.employee_id.id),
         ('type', '=', 'dominical'),
         ('state', '=', 'validate')])
    tot_horas = 0
    for hr_ex in horas_extra:
        tot_horas += hr_ex.hour
    monto_dia = contract.wage / 30
    monto_hora = (monto_dia / 8) * 3
    monto_bono = monto_hora * tot_horas
    return monto_bono


def calculo_horas_recargo_nocturno(payslip):
    contract = payslip.contract_id
    horas = payslip.dict.env['hr.horas.extra']
    start = payslip.date_from
    end = payslip.date_to
    horas_extra = horas.search(
        [('date', '<=', end),
         ('date', '>=', start),
         ('employee_id', '=', contract.employee_id.id),
         ('type', '=', 'nocturno'),
         ('state', '=', 'validate')])
    tot_horas = 0
    for hr_ex in horas_extra:
        tot_horas += hr_ex.hour
    monto_dia = contract.wage / 30
    monto_hora = (monto_dia / 8) * 2
    monto_recar = monto_hora * (float(contract.recar_nocturno) / 100)
    monto_bono = monto_recar * tot_horas
    return monto_bono


def calculo_otros_bonos(payslip):
    contract = payslip.contract_id
    tot_bono = 0
    for bono in contract.bono_ids:
        tot_bono += bono.amount
    return tot_bono


def calculo_rciva(payslip, total_rciva):
    contract = payslip.contract_id
    rc = payslip.dict.env['hr.rciva']
    start = payslip.date_from
    end = payslip.date_to
    horas_rciva = rc.search(
        [('date_from', '<=', end),
         ('date_to', '>', start),
         ('employee_id', '=', contract.employee_id.id)])
    tot_rc = 0
    saldo_favor = 0
    saldo_favor_actual = 0
    if horas_rciva:
        tot_rc = horas_rciva[0].amount_iva
        total = total_rciva - tot_rc
        if total < 0:
            if horas_rciva:
                horas_rciva[0].amount_saldo = total * -1
                saldo_favor_actual = total * -1
        # Calcular el UFV con saldo anterior
        ufv_ini = float(horas_rciva[0].ufv_inicial_val)
        ufv_fin = float(horas_rciva[0].ufv_final_val)

        rciva_ant = rc.search(
            [('date_to', '<', start),
             ('employee_id', '=', contract.employee_id.id),
             ('amount_saldo', '>', 0)], order="date_to desc", limit=1)
        total_ufv = 0
        if rciva_ant:
            total_ufv = ((ufv_fin / ufv_ini) - 1) * rciva_ant[0].amount_saldo
            saldo_favor = rciva_ant[0].amount_saldo
        tot_rc -= total_ufv
    return tot_rc, saldo_favor, saldo_favor_actual


def importe_rciva(payslip):
    contract = payslip.contract_id
    rc = payslip.dict.env['hr.rciva']
    start = payslip.date_from
    end = payslip.date_to
    horas_rciva = rc.search(
        [('date_from', '<=', end),
         ('date_to', '>', start),
         ('employee_id', '=', contract.employee_id.id)])
    tot_rc = 0
    if horas_rciva:
        tot_rc = horas_rciva[0].amount_iva
    return tot_rc


def basico_anterior_min(payslip, amount):
    retro = payslip.dict.env['hr.retroactivo.data']
    year = payslip.date_from.year
    retro_data = retro.search([('name', '=', str(year))])
    monto = amount * (retro_data[0].percen_bas / 100)
    return monto

def basico_anterior_max(payslip, amount):
    retro = payslip.dict.env['hr.retroactivo.data']
    year = payslip.date_from.year
    retro_data = retro.search([('name', '=', str(year))])
    monto = amount * (retro_data[0].percen_min / 100)
    return monto
