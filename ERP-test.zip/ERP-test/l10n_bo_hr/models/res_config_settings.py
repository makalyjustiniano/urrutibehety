import logging
from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    sueldo_min = fields.Float(string='Sueldo mínimo actual', related='company_id.sueldo_min', readonly=False)
    sueldo_min_ant = fields.Float(string='Sueldo mínimo anterior', related='company_id.sueldo_min_ant', readonly=False)
