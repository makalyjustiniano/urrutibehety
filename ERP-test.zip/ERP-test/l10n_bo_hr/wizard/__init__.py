# -*- coding: utf-8 -*-
from . import payroll_ministry
from . import payroll_afp
from . import payroll_rciva
from . import payroll_aportes
from . import payroll_aguinaldo
from . import hr_payroll_payslips_by_employees
from . import reprogramar_prestamo
from . import adelantar_prestamo
from . import actualizar_salario
