# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import datetime, date
from odoo.tools import float_is_zero
from odoo.osv import expression


class ActualizarSalario(models.TransientModel):
    _name = "actualizar.salario"
    _description = "Adelantar de Prestamos"

    def _get_available_contracts_domain(self):
        return [('contract_ids.state', 'in', ('open', 'close')), ('company_id', '=', self.env.company.id)]

    def _get_employees(self):
        active_employee_ids = self.env.context.get('active_employee_ids', False)
        if active_employee_ids:
            return self.env['hr.employee'].browse(active_employee_ids)
        return self.env['hr.employee'].search(self._get_available_contracts_domain())

    retro_id = fields.Many2one('hr.retroactivo.data', string='Gestión Actualizar', required=True)
    employee_ids = fields.Many2many('hr.employee', 'hr_employee_group_salario_rel', 'salario_id', 'employee_id',
                                    'Empleados',
                                    default=lambda self: self._get_employees(), required=True,
                                    compute='_compute_employee_ids', store=True, readonly=False)
    department_id = fields.Many2one('hr.department')
    company_id = fields.Many2one('res.company', default=lambda self: self.env.company, required=True)

    @api.depends('department_id')
    def _compute_employee_ids(self):
        for wizard in self:
            domain = wizard._get_available_contracts_domain()
            if wizard.department_id:
                domain = expression.AND([
                    domain,
                    [('department_id', 'child_of', self.department_id.id)]
                ])
            wizard.employee_ids = self.env['hr.employee'].search(domain)

    def compute_update(self):
        employees = self.with_context(active_test=False).employee_ids
        fecha_ini = date(year=int(self.retro_id.name), month=5, day=1)
        fecha_fin = date(year=int(self.retro_id.name), month=5, day=31)
        contracts = employees._get_contracts(
            fecha_ini, fecha_fin, states=['open', 'close']
        ).filtered(lambda c: c.active)
        sal_min_ant = self.company_id.sueldo_min_ant
        contr_ids = []
        for contract in contracts:
            salario = contract.wage
            if contract.wage > sal_min_ant:
                contract.wage = salario + contract.wage * (self.retro_id.percen_bas/100)
                contr_ids.append(contract.id)
            elif contract.wage == sal_min_ant:
                contract.wage = salario + contract.wage * (self.retro_id.percen_min/100)
                contr_ids.append(contract.id)

        action = self.env["ir.actions.actions"]._for_xml_id("hr_contract.action_hr_contract")
        action.update({'domain': [('id', 'in', contr_ids)]})
        return action
