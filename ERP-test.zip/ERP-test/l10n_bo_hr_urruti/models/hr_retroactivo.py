from odoo import fields, models, api, _


class HrRetroactivoData(models.Model):
    _inherit = 'hr.retroactivo.data'

    type_irru = fields.Selection(string='Nro Salario',
                                 selection=[('s11', 'Salario'),
                                            ('s12', 'Salario 12'),
                                            ('s13', 'Salario 13'),
                                            ('s14', 'Salario 14'),
                                            ('s15', 'Salario 15')],
                                 copy=False, default='s11')
    min_wage = fields.Float(string='Salario Mínimo')
    max_wage = fields.Float(string='Salario Máximo')
