from odoo import models, fields, api


class Payslip(models.Model):
    _inherit = 'hr.payslip'

    def _get_base_local_dict(self):
        res = super()._get_base_local_dict()
        res.update({
            'basico_anterior_min': basico_anterior_min,
            'basico_anterior_min_ss': basico_anterior_min_ss,
            'basico_anterior_max': basico_anterior_max,
            'basico_anterior_max_ss': basico_anterior_max_ss,
        })
        return res


def basico_anterior_min(payslip, amount):
    retro = payslip.dict.env['hr.retroactivo.data']
    year = payslip.date_from.year
    retro_data = retro.search(
        [('name', '=', str(year)),
         ('max_wage', '>', amount),
         ('min_wage', '<', amount),
         ('type_irru', '=', 's11')])
    if retro_data:
        monto = amount * (retro_data[0].percen_bas / 100)
    else:
        monto = 0
    return monto


def basico_anterior_max(payslip, amount):
    retro = payslip.dict.env['hr.retroactivo.data']
    year = payslip.date_from.year
    retro_data = retro.search(
        [('name', '=', str(year)),
         ('max_wage', '>', amount),
         ('min_wage', '<', amount),
         ('type_irru', '=', 's11')])
    if retro_data:
        monto = amount * (retro_data[0].percen_min / 100)
    else:
        monto = 0
    return monto


def basico_anterior_min_ss(payslip, amount, type):
    retro = payslip.dict.env['hr.retroactivo.data']
    year = payslip.date_from.year
    retro_data = retro.search(
        [('name', '=', str(year)),
         ('max_wage', '>', amount),
         ('min_wage', '<', amount),
         ('type_irru', '=', type)])
    if retro_data:
        monto = amount * (retro_data[0].percen_bas / 100)
    else:
        monto = 0
    return monto


def basico_anterior_max_ss(payslip, amount, type):
    retro = payslip.dict.env['hr.retroactivo.data']
    year = payslip.date_from.year
    retro_data = retro.search(
        [('name', '=', str(year)),
         ('max_wage', '>', amount),
         ('min_wage', '<', amount),
         ('type_irru', '=', type)])
    if retro_data:
        monto = amount * (retro_data[0].percen_min / 100)
    else:
        monto = 0
    return monto
