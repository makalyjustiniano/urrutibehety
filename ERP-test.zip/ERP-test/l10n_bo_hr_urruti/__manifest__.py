# -*- coding: utf-8 -*-
{
    'name': "Bolivia HHRR Urrutibehety",
    'summary': """
        Bolivian HR Localization Personalización Cliente
        """,
    'description': """
        Bolivian HR Localizacion Boliviana
    """,
    'author': "sapex.miguel@gmail.com",
    'category': 'Human Resources/Payroll',
    'version': '15.0.0.1',
    'depends': ['hr_holidays',
                'hr_payroll',
                'l10n_bo_hr',
                'hr_contract_salary',
                'hr'],
    'data': [
        # 'security/ir.model.access.csv',
        # 'data/data_retroactivo_12_bo.xml',
        'views/hr_employee_views.xml',
        'views/hr_contract_views.xml',
        'views/hr_finiquito_view.xml',
        'views/hr_contract_history_report_views.xml',
        'wizard/payroll_ministry.xml',
        'wizard/hr_payroll_payslips_by_employees_views.xml'
    ],
}
