# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from datetime import datetime, date
from odoo.osv import expression


class ActualizarSalario(models.TransientModel):
    _inherit = "actualizar.salario"
    _description = "Adelantar de Prestamos"

    def compute_update(self):
        employees = self.with_context(active_test=False).employee_ids
        fecha_ini = date(year=int(self.retro_id.name), month=5, day=1)
        fecha_fin = date(year=int(self.retro_id.name), month=5, day=31)
        contracts = employees._get_contracts(
            fecha_ini, fecha_fin, states=['open', 'close']
        ).filtered(lambda c: c.active)
        sal_min_ant = self.company_id.sueldo_min_ant
        contr_ids = []
        for contract in contracts:
            salario = contract.wage
            if contract.wage > sal_min_ant:
                contract.wage = salario + contract.wage * (self.retro_id.percen_bas / 100)
                contr_ids.append(contract.id)
            elif contract.wage == sal_min_ant:
                contract.wage = salario + contract.wage * (self.retro_id.percen_min / 100)
                contr_ids.append(contract.id)

        action = self.env["ir.actions.actions"]._for_xml_id("hr_contract.action_hr_contract")
        action.update({'domain': [('id', 'in', contr_ids)]})
        return action
