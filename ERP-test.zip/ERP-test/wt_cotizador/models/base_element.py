# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class BaseElement(models.Model):
    _name = 'base.element'
    _description = "Base Element"

    name = fields.Char(string="Elemento Base",required=True)
    description = fields.Char(string="Descripción")