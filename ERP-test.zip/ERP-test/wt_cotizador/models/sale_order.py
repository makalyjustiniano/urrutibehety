# -*- coding: utf-8 -*-
import re
import json

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SaleOrder(models.Model):
    _inherit = "sale.order"

    operations_ids = fields.One2many('operations.lines','sale_id',string="Operarios")

    d_quotation_id = fields.Many2one('draft.quotation',string="Draft Quotation Reference Id")

    service_product_ids = fields.One2many('service.product','sale_product_id',string="Service Products")

    sale_order_type = fields.Selection([('default', 'Default'),('summary', 'Summary'),],'Quotation Type',default="default")


    @api.model
    def create(self,vals):
        if vals.get('sale_order_type'):
            if vals['sale_order_type'] == 'summary':
                vals['name'] = self.env['ir.sequence'].next_by_code('sale.order.summary') or _('New')

        res = super(SaleOrder, self).create(vals)

        return res
        
    # for sync products in sale order
    
    def sync_products(self):

        for operationline in self.operations_ids:

            key_val_dict = dict(operationline.operations_id._fields['operator_type'].selection)

   
            for product in operationline.operations_id.line_ids:
                for o in self.order_line:
                    if product.product_id.id == o.product_id.id:
                        o.unlink()



        ## FOR ADD Muebles's selection field to add in var_dictionary for variable

        # for convert selection field (tipo_de_material_muebles) to dictionary
        dict_tipo_de_material_muebles_select  = dict(self.d_quotation_id._fields['tipo_de_material_muebles'].selection)

        # For MAQUINARIA Y EQUIPOS calculation
        d_muebles = {}
        for k in dict_tipo_de_material_muebles_select:
            d_muebles[k] = 0

        for line in self.d_quotation_id.mueble_lines_ids:
            if d_muebles.get(line.cotiza_product_id):
                d_muebles[line.cotiza_product_id] = d_muebles[line.cotiza_product_id] + line.cant
            else:
                d_muebles[line.cotiza_product_id] = line.cant



        ## FOR ADD Maquinaria'S selection field to add in var_dictionary for variable

        # for convert selection field (descripcion_maquinaria) to dictionary
        dict_descripcion_maquinaria_select  = dict(self.d_quotation_id._fields['descripcion_maquinaria'].selection)

        # For MAQUINARIA Y EQUIPOS calculation
        d_maquinaria = {}
        for k in dict_descripcion_maquinaria_select:
            d_maquinaria[k] = 0

        for line in self.d_quotation_id.machinery_lines_ids:
            if d_maquinaria.get(line.cotiza_product_id):
                d_maquinaria[line.cotiza_product_id] = d_maquinaria[line.cotiza_product_id] + line.cant
            else:
                d_maquinaria[line.cotiza_product_id] = line.cant

        # print("d_maquinaria >>>>>....",d_maquinaria)



        ## FOR ADD PISOS'S selection field to add in var_dictionary for variable

        # for convert selection field (tipo_de_piso_id_pisos) to dictionary
        dict_tipo_de_piso_id_pisos_select  = dict(self.d_quotation_id._fields['tipo_de_piso_id_pisos'].selection)

        # print("dict_tipo_de_piso_id_pisos_select  =  ",dict_tipo_de_piso_id_pisos_select)

        # For Tipo de Pisos calculation
        d_pisos = {}
        for k in dict_tipo_de_piso_id_pisos_select:
            d_pisos[k] = 0

        for line in self.d_quotation_id.piso_lines_ids:
            if d_pisos.get(line.cotiza_product_id):
                d_pisos[line.cotiza_product_id] = d_pisos[line.cotiza_product_id] + line.cant
            else:
                d_pisos[line.cotiza_product_id] = line.cant
        d_pisos["PIS01"] = d_pisos["PIS01_1"]+d_pisos["PIS01_2"]+d_pisos["PIS01_3"]



        ## var_dictionary use for taking a variables for use in formula's of products count

        var_dictionary = {}

        # Add d_muebles to var_dictionary   (eg . {"MUEB1":0, "MUEB2":10 ....})
        for k in d_muebles:
            var_dictionary[k] = d_muebles[k]

        # Add d_pisos to var_dictionary   (eg . {"PIS01":0, "PIS02":10 ....})
        for k in d_pisos:
            var_dictionary[k] = d_pisos[k]

        # Add d_maquinaria to var_dictionary   (eg . {"MYE01":0, "MYE02":10 ....})
        for k in d_maquinaria:
            var_dictionary[k] = d_maquinaria[k]
        
        ## For add operator's values in var_dictionary
        for operationline in self.operations_ids:
            for operator in key_val_dict.keys():
                # if (operator not in var_dictionary) or (var_dictionary[operator]==1):
                # if (operator not in var_dictionary):
                # var_dictionary[operator] = operationline.qty if operationline.operations_id.name==operator else 0

                if operator==operationline.operations_id.operator_type:
                    var_dictionary[operator] = operationline.qty
                elif (operator not in var_dictionary.keys()):
                    var_dictionary[operator] = 0

        # print("var_dictionary",var_dictionary)


        var_dictionary['INM'] = self.d_quotation_id.INM

        var_dictionary['COPE'] = self.d_quotation_id.COPE
        var_dictionary['CFUN'] = self.d_quotation_id.CFUN
        var_dictionary['CBAN'] = self.d_quotation_id.CBAN
        var_dictionary['CINO'] = self.d_quotation_id.CINO
        var_dictionary['CURI'] = self.d_quotation_id.CURI
        var_dictionary['CDUC'] = self.d_quotation_id.CDUC

        var_dictionary['MATH'] = str(self.d_quotation_id.material_higienico_banos)


        print("var_dictionary",var_dictionary)

        # This function use for solution of IF formula and return it's answer
        def get_solution_of_if_formula(formula,dictionary):
            for key,val in dictionary.items():
                exec(key + '=val')

            # print("NEW_DICTIONARY",dictionary)
            l = formula.replace('IF(', '')
            x=list(l.strip())
            x.pop()
            formula="".join(x)
            
            f_list = formula.split(';')
            # print(f_list)
            
            c_f = f_list[0]
            i_f = f_list[1]
            e_f = f_list[2]
            
            # print(c_f)
            
            if eval(c_f):
                return eval(i_f)
            else:
                return eval(e_f)

        # This function use for solve the formula and return final answer
        def operation_formula(formula,dictionary):
            counter = formula.count('IF')
            
            # This if is use for simple formula (without IF)
            if counter == 0:

                # This For loop is for taking dictionary's keys as a variables and dictionary's values as value of that variable
                for key,val in dictionary.items():
                    exec(key + '=val')

                return eval(formula)

            # This elif is use for one IF formula (Having 1 IF)
            elif counter == 1:
                return get_solution_of_if_formula(formula,dictionary)

            # This else is use for two IF formula (Having 2 IF)
            else:
                # return "Developing"
                
                l = formula.split('+IF(')
                # print(l)
                
                f_n = formula.replace(l[0],str(get_solution_of_if_formula(l[0],dictionary)))
                f_nn = f_n.replace("IF("+l[1],str(get_solution_of_if_formula(l[1],dictionary)))
                
                # print(f_nn)
                return eval(f_nn)

        # This dictionary use for add ("p" + product's code) as key and it's quantity for it's value
        product_qty_dict = {"p001":0,"p002":0,"p003":0,"p004":0,"p005":0,"p006":0,"p007":0,"p008":0,"p009":0,"p010":0,"p011":0,"p012":0,"p013":0,"p014":0,"p015":0,"p016":0,"p017":0,"p018":0,"p019":0,"p020":0,"p021":0,"p022":0,"p023":0,"p024":0,"p025":0,"p026":0,"p027":0,"p028":0,"p029":0,"p030":0,"p031":0,"p032":0,"p033":0,"p034":0,"p035":0,"p036":0,"p037":0,"p038":0,"p039":0,"p040":0,"p041":0,"p042":0,"p043":0,"p044":0,"p045":0,"p046":0,"p047":0,"p048":0,"p049":0,"p050":0,"p051":0,"p052":0,"p053":0,"p054":0,"p055":0,"p056":0,"p057":0,"p058":0,"p059":0,"p060":0,"p061":0,"p062":0,"p063":0,"p064":0,"p065":0,"p066":0,"p067":0,"p068":0,"p069":0,"p070":0,"p071":0,"p072":0,"p073":0,"p074":0,"p075":0,"p076":0,"p077":0,"p078":0,"p079":0,"p080":0,"p081":0,"p082":0,"p083":0,"p084":0,"p085":0,"p086":0,"p087":0,"p088":0,"p089":0,"p090":0,"p091":0,"p092":0,"p093":0,"p094":0,"p095":0,"p096":0,"p097":0,"p098":0,"p099":0,"p100":0,}




        # From Here all products are Starting to sync

        for operationline in self.operations_ids:

            for product in operationline.operations_id.line_ids:

                if product.product_id.product_type!='product':

                    existing_order_id = 0

                    for o in self.order_line:
                        if product.product_id.id == o.product_id.id:
                            existing_order_id = o.id
                            order = o

                    vals = {'product_id':product.product_id.id,
                        # 'product_uom':product.uom_id.id,
                        'price_unit':product.product_id.list_price,}

                    # # For change the format of formula
                    new_formula = product.product_id.formula
                    new_formula = new_formula.replace(" ","")
                    new_formula = new_formula.replace("MATH=='S'","MATH")
                    new_formula = new_formula.replace("x","*")
                    new_formula = new_formula.replace("X","*")
                    new_formula = new_formula.replace(",",".")
                    new_formula = new_formula.replace("%","/100")
                    # print('new_formula>>>>>>>>>>>>',new_formula,"for product ",product.product_id.default_code)

                    # if product not present in order line and type is operator
                    if existing_order_id==0:
                        vals['product_uom'] = product.uom_id.id
                        vals['product_uom_qty'] = operation_formula(new_formula,var_dictionary)
                        self.write({'order_line':[(0, 0,  vals) ]})
                        product_qty_dict['p'+product.product_id.default_code] = vals['product_uom_qty']

                    # # else update that line's values

                    # else:
                    #     vals['product_uom_qty'] = order.product_uom_qty + (operationline.qty * product.per_unit)
                    #     self.write({'order_line':[(1, existing_order_id, vals) ]})

        l = ["001","002","003","004","005","006","007","008","009","010","011","012","013","014","015","016","017","018","019","020","021","022","023","024","025","026","027","028","029","030","031","032","033","034","035","036","037","038","039","040","041","042","043","044","045","046","047","048","049","050","051","052","053","054","055","056","057","058","059","060","061","062","063","064","065","066","067","068","069","070","071","072","073","074","075","076","077","078","079","080","081","082","083","084","085","086","087","088","089","090","091","092","093","094","095","096","097","098","099","100"]



        for operationline in self.operations_ids:

            for product in operationline.operations_id.line_ids:

                if product.product_id.product_type=='product':

                    # this variable use for check the same product is available or not
                    existing_order_id = 0

                    for o in self.order_line:
                        if o.product_id.default_code:
                            product_qty_dict["p"+o.product_id.default_code] = o.product_uom_qty

                        if product.product_id.id == o.product_id.id:
                            existing_order_id = o.id
                            order = o

                    vals = {'product_id':product.product_id.id,
                        # 'product_uom':product.uom_id.id,
                        'price_unit':product.product_id.list_price,}

                    # For change the format of formula
                    new_formula =  product.product_id.formula
                    for old in l:
                        new_formula = new_formula.replace(old,"p"+old)
                    new_formula = new_formula.replace(" ","")
                    new_formula = new_formula.replace("MATH=='S'","MATH")
                    new_formula = new_formula.replace("x","*")
                    new_formula = new_formula.replace("X","*")
                    new_formula = new_formula.replace(",",".")
                    new_formula = new_formula.replace("%","/100")
                    # print('new_formula >>>> ',new_formula,"for product ",product.product_id.default_code)

                    # print('product_qty_dict $$$$$$$',product_qty_dict)
                    for k in product_qty_dict:
                        var_dictionary[k] = product_qty_dict[k]

                    # print('var_dictionary @@@@@@@@@@@@@ ',var_dictionary)
                    if existing_order_id==0:
                        vals['product_uom'] = product.uom_id.id
                        vals['product_uom_qty'] = operation_formula(new_formula,var_dictionary)
                        self.write({'order_line':[(0, 0,  vals) ]})
                        product_qty_dict['p'+'default_code'] = vals['product_uom_qty']

        # For add "operations" type products in sale order
        for o_line in self.operations_ids:
            productLine_vals = {"product_id":o_line.operations_id.product_id.id,
                                "price_unit":o_line.operations_id.product_id.list_price,
                                "product_uom":o_line.operations_id.product_id.uom_id.id,
                                "product_uom_qty":o_line.qty,}
            self.write({'order_line':[(0, 0,  productLine_vals) ]})

        # For find diffrent types of product category
        pc_list = []
        for line in self.order_line:
            pc_name = line.product_id.categ_id.name
            if pc_name not in pc_list:
                pc_list.append(pc_name)

        print(pc_list)

        # Now Again Replace all products by its categoty wise
        for pc_name in pc_list:
            vals = {"display_type":"line_section",
            "name":pc_name,
            "product_uom_qty":0,
            "product_uom":0,
            "price_unit":0,
            "discount":0
            }
            self.write({'order_line':[(0, 0,  vals) ]})

            for line in self.order_line:
                if line.product_id.categ_id.name == pc_name:
                    if not line.display_type:
                        n_val = {'product_id':line.product_id.id,
                                'name':line.name,
                                'product_uom_qty':line.product_uom_qty,
                                'product_uom':line.product_uom.id,
                                'price_unit':line.price_unit,
                                'discount':line.discount,
                                }
                        self.write({'order_line':[(0, 0,  n_val) ]})
                        line.unlink()





    # For Add 3 Products of service in sale order

    def add_three_service_products(self):

        p1_rec = 0
        p2_rec = 0
        p3_rec = 0

        total = 0

        for line in self.order_line:
            if line.product_id.default_code == "P1" and p1_rec==0:
                p1_rec = line
            elif line.product_id.default_code == "P2" and p2_rec==0:
                p2_rec = line
            elif line.product_id.default_code == "P3" and p3_rec==0:
                p3_rec = line
            else:
                if line.product_id.product_type == "operations":
                    total = total + line.price_unit*line.product_uom_qty

        # print('total ======== ',total)

        sp_p1_rec_percentage = 0
        sp_p2_rec_percentage = 0
        sp_p3_rec_percentage = 0

        sp_p1_rec = 0
        sp_p2_rec = 0
        sp_p3_rec = 0

        for sp in self.service_product_ids:
            if sp.product_id.default_code == "P1":
                sp_p1_rec_percentage = sp.qty_percentage/100
                sp_p1_rec = sp
            elif sp.product_id.default_code == "P2":
                sp_p2_rec_percentage = sp.qty_percentage/100
                sp_p2_rec = sp
            elif sp.product_id.default_code == "P3":
                sp_p3_rec_percentage = sp.qty_percentage/100
                sp_p3_rec = sp

        if p1_rec!=0:
            p1_rec.unlink()
        if p2_rec!=0:
            p2_rec.unlink()
        if p3_rec!=0:
            p3_rec.unlink()

        # total = 0
        # d = json.loads(self.tax_totals_json)
        # total = d["subtotals"][0]["amount"]

        if sp_p1_rec_percentage==0:
            p1_price_unit = 0
        else:
            p1_price_unit = total

        # p1_price_unit = total

        total_1 = 0
        for line in self.order_line:
            if line.product_id.default_code != "service" or line.product_id.product_type=="operations":
                total_1 = total_1 + line.price_unit*line.product_uom_qty

        # For add section in sale order
        p1 = self.env['product.product'].search([('default_code','=','P1')])
        val_section = {"display_type":"line_section",
            "name":p1.categ_id.name,
            }
        self.write({'order_line':[(0, 0, val_section) ]})


        if sp_p1_rec!=0:
            # p1 = self.env['product.product'].search([('default_code','=','P1')])
            p1_vals = {'product_id':p1.id,
                        'product_template_id':p1.id,
                        'product_uom_qty':sp_p1_rec_percentage,
                        'price_unit':sp_p1_rec.unit_price,
                        }
            if p1_rec==0:
                self.write({'order_line':[(0, 0,  p1_vals) ]})
            else:
                p1_rec.write({'price_unit':sp_p1_rec.unit_price,
                            'product_uom_qty':sp_p1_rec_percentage,
                        })

            if sp_p2_rec_percentage==0:
                p2_price_unit = 0 
            else:
                p2_price_unit = total_1 + (p1_price_unit * sp_p1_rec_percentage)
        else:
            if sp_p2_rec_percentage==0:
                p2_price_unit = 0
            else:
                p2_price_unit = total_1




        if sp_p2_rec!=0:
            p2 = self.env['product.product'].search([('default_code','=','P2')])
            p2_vals = {'product_id':p2.id,
                    'product_template_id':p2.id,
                    'product_uom_qty':sp_p2_rec_percentage,
                    'price_unit':sp_p2_rec.unit_price,
                    }

            if p2_rec==0:
                self.write({'order_line':[(0, 0,  p2_vals)]})
            else:
                p2_rec.write({'price_unit':sp_p2_rec.unit_price,
                            'product_uom_qty':sp_p2_rec_percentage,
                    })

            if sp_p3_rec_percentage==0:
                p3_price_unit = 0 
            else:
                p3_price_unit = p2_price_unit + (p2_price_unit * sp_p2_rec_percentage)
        else:
            if sp_p3_rec_percentage==0:
                p3_price_unit = 0 
            else:
                p3_price_unit = p2_price_unit

        if sp_p3_rec!=0:
            p3 = self.env['product.product'].search([('default_code','=','P3')])
            p3_vals = {'product_id':p3.id,
                        'product_template_id':p3.id,
                        'product_uom_qty':sp_p3_rec_percentage,
                        'price_unit':sp_p3_rec.unit_price,
                        }

            if p3_rec==0:
                self.write({'order_line':[(0, 0,  p3_vals) ]})
            else:
                p3_rec.write({'price_unit':sp_p3_rec.unit_price,
                            'product_uom_qty':sp_p3_rec_percentage,
                            })

        for sp in self.service_product_ids:
            if sp.product_id.default_code == "P1":
                sp.unit_price = p1_price_unit
            elif sp.product_id.default_code == "P2":
                sp.unit_price = p2_price_unit
            elif sp.product_id.default_code == "P3":
                sp.unit_price = p3_price_unit

        # # For find diffrent types of product category
        # pc_list = []
        # for line in self.order_line:
        #     pc_name = line.product_id.categ_id.name
        #     if pc_name not in pc_list:
        #         pc_list.append(pc_name)

        # print(pc_list)

        # # Now Again Replace all products by its categoty wise
        # for pc_name in pc_list:
        #     vals = {"display_type":"line_section",
        #     "name":pc_name,
        #     "product_uom_qty":0,
        #     "product_uom":0,
        #     "price_unit":0,
        #     "discount":0
        #     }
        #     self.write({'order_line':[(0, 0,  vals) ]})

        #     for line in self.order_line:
        #         if line.product_id.categ_id.name == pc_name:
        #             n_val = {'product_id':line.product_id.id,
        #                     'name':line.name,
        #                     'product_uom_qty':line.product_uom_qty,
        #                     'product_uom':line.product_uom.id,
        #                     'price_unit':line.price_unit,
        #                     'discount':line.discount,
        #                     }
        #             self.write({'order_line':[(0, 0,  n_val) ]})
        #             line.unlink()


    # For calculate service products
    def calculate_three_service_products(self):
        p1_rec = 0
        p2_rec = 0
        p3_rec = 0

        total = 0

        for line in self.order_line:
            if line.product_id.default_code == "P1" and p1_rec==0:
                p1_rec = line
            elif line.product_id.default_code == "P2" and p2_rec==0:
                p2_rec = line
            elif line.product_id.default_code == "P3" and p3_rec==0:
                p3_rec = line
            else:
                if line.product_id.product_type == "operations":
                    total = total + line.price_unit*line.product_uom_qty

        sp_p1_rec_percentage = 0
        sp_p2_rec_percentage = 0
        sp_p3_rec_percentage = 0

        sp_p1_rec = 0
        sp_p2_rec = 0
        sp_p3_rec = 0

        for sp in self.service_product_ids:
            if sp.product_id.default_code == "P1":
                sp_p1_rec_percentage = sp.qty_percentage/100
                sp_p1_rec = sp
            elif sp.product_id.default_code == "P2":
                sp_p2_rec_percentage = sp.qty_percentage/100
                sp_p2_rec = sp
            elif sp.product_id.default_code == "P3":
                sp_p3_rec_percentage = sp.qty_percentage/100
                sp_p3_rec = sp

        # if p1_rec!=0:
        #     p1_rec.unlink()
        # if p2_rec!=0:
        #     p2_rec.unlink()
        # if p3_rec!=0:
        #     p3_rec.unlink()

        # total = 0
        # d = json.loads(self.tax_totals_json)
        # total = d["subtotals"][0]["amount"]


        if sp_p1_rec_percentage!=0:
            p1_price_unit = total
        else:
            p1_price_unit = 0

        total_1 = 0
        # p1_price_unit = total
        for line in self.order_line:
             if line.product_id.default_code != "service" or line.product_id.product_type=="operations":
                    total_1 = total_1 + line.price_unit*line.product_uom_qty

        if sp_p1_rec!=0:
            if sp_p2_rec_percentage==0:
                p2_price_unit = 0 
            else:
                p2_price_unit = total_1 + (p1_price_unit * sp_p1_rec_percentage)
        else:
            if sp_p2_rec_percentage==0:
                p2_price_unit = 0
            else:
                p2_price_unit = total_1


        if sp_p2_rec!=0:
            if sp_p3_rec_percentage==0:
                p3_price_unit = 0 
            else:
                p3_price_unit = p2_price_unit + (p2_price_unit * sp_p2_rec_percentage)
        else:
            if sp_p3_rec_percentage==0:
                p3_price_unit = 0 
            else:
                p3_price_unit = p2_price_unit


        for sp in self.service_product_ids:
            if sp.product_id.default_code == "P1":
                sp.unit_price = p1_price_unit
            elif sp.product_id.default_code == "P2":
                sp.unit_price = p2_price_unit
            elif sp.product_id.default_code == "P3":
                sp.unit_price = p3_price_unit





    def action_create_summary_quotation(self):
        active_ids = self.ids
        sale_order_name = [] 

        partner_id = 0
        ptr_parent_id = 0
        d_quotation_id = 0


        for so in self:
            if partner_id==0:
                partner_id = so.partner_id
                d_quotation_id = so.d_quotation_id
                ptr_parent_id = so.partner_id.parent_id.id
            elif ptr_parent_id!=0 and ptr_parent_id!=so.partner_id.parent_id.id:
                raise ValidationError(_("You can only create summary quotation for same customer"))
            elif ptr_parent_id==0 and partner_id!=so.partner_id.id:
                raise ValidationError(_("You can only create summary quotation for same customer"))
            elif ptr_parent_id==0:
                ptr_parent_id = so.partner_id.parent_id.id

            if so.sale_order_type == 'summary':
                raise ValidationError(_("You can not create summary quotation from summary type of quotations"))

            sale_order_name.append(so.name)


        s_q_order = self.env['sale.order'].create({'partner_id':partner_id.id,
                                                    'd_quotation_id':d_quotation_id.id,
                                                    'origin':",".join(sale_order_name),
                                                    'sale_order_type':'summary'
                                                    })

        for so in self:
            for line in so.order_line:
                if not line.display_type:
                    vals = {'product_id':line.product_id.id,
                        'product_uom_qty':line.product_uom_qty,
                        "product_uom":line.product_uom.id,
                        'price_unit':line.price_unit,
                        }
                    s_q_order.write({'order_line':[(0, 0,  vals) ]})

        # For find diffrent types of product category
        pc_list = []
        for line in s_q_order.order_line:
            pc_name = line.product_id.categ_id.name
            if pc_name not in pc_list:
                pc_list.append(pc_name)

        print(pc_list)

        # Now Again Replace all products by its categoty wise
        for pc_name in pc_list:
            vals = {"display_type":"line_section",
            "name":pc_name,
            "product_uom_qty":0,
            "product_uom":0,
            "price_unit":0,
            "discount":0
            }
            s_q_order.write({'order_line':[(0, 0,  vals) ]})

            for line in s_q_order.order_line:
                if line.product_id.categ_id.name == pc_name:
                    if not line.display_type:
                        n_val = {'product_id':line.product_id.id,
                                'name':line.name,
                                'product_uom_qty':line.product_uom_qty,
                                'product_uom':line.product_uom.id,
                                'price_unit':line.price_unit,
                                'discount':line.discount,
                                }
                        s_q_order.write({'order_line':[(0, 0,  n_val) ]})
                        line.unlink()










class OperationsLines(models.Model):
    _name = "operations.lines"

    operations_id = fields.Many2one('product.type',string="Operarios")
    qty = fields.Integer(string="Quantity")
 
    sale_id = fields.Many2one('sale.order')

