# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class City(models.Model):
    _name = 'city.city'
    _description = "City Details"

    name = fields.Char(string="Ciudad",required=True)
    description = fields.Char(string="Descripción")