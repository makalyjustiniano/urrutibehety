# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Location(models.Model):
    _name = 'location.type'
    _description = "Location Details"

    name = fields.Char(string="Tipo Locación",required=True)
    description = fields.Char(string="Descripción")