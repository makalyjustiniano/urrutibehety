# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class ProductFormulaType(models.Model):
    _name = "product.formula.type"

    # product_type = fields.Selection([('operations','Operation'),('tipos_de_pisos','Tipos de pisos'),('tipos_de_muebles','Tipos de Muebles'),('insumos','Insumos')],string="Product Type")

class ProductProduct(models.Model):
    _inherit = "product.product"

    product_type = fields.Selection([('operations','Operation'),('product','Product'),('other','Other')],string="Product Type")

    formula = fields.Char(string="Formula")
