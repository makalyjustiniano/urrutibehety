# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Otro(models.Model):
    _name = 'otro.otro'
    _description = "Otro Details"

    name = fields.Char(string="Otro",required=True)
    description = fields.Char(string="Descripción")