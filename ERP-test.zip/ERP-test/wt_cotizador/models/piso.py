# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Piso(models.Model):
    _name = 'piso.piso'
    _description = "Piso Details"

    name = fields.Char(string="Piso",required=True)
    description = fields.Char(string="Descripción")