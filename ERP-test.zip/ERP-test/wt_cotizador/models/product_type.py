# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class ProductType(models.Model):
	_name = 'product.type'
	_description = 'Product Type'

	name = fields.Char(string='Name')
	line_ids = fields.One2many('product.list','product_type_id',string="Products List")
	operator_type = fields.Selection([('OP1H','OP1H'),('OP2H','OP2H'),('OP3H','OP3H'),('OP4H','OP4H'),('OP5H','OP5H'),('OP6H','OP6H'),('OP7H','OP7H'),('OP8H','OP8H'),('OP8HS','OP8HS'),('OP9H','OP9H'),('OP10H','OP10H'),('OP11H','OP11H'),('OP12H','OP12H')],'Operator Type',required=True)
	product_id = fields.Many2one('product.product',string="My product",required=True)

class ProductList(models.Model):
	_name = 'product.list'
	_description = 'Product List'
	_rec_name = 'product_id'

	product_id = fields.Many2one('product.product',string = "Detalle",required=True)
	uom_id = fields.Many2one('uom.uom',string="Unit of Measure")
	qty = fields.Float(string='Quantity')
	per_unit = fields.Float(string='Per Unit')
	product_type_id = fields.Many2one('product.type',string='Product List')

	@api.onchange('product_id')
	def _get_uom_id(self):
		self.uom_id = self.product_id.uom_po_id
