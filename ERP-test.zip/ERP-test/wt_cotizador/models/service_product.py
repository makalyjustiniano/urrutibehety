# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class ServiceProduct(models.Model):
    _name = 'service.product'
    _description = "Service Product"

    product_id = fields.Many2one('product.product',string="Product",domain="[('detailed_type', '=', 'service')]",required=True)
    qty_percentage = fields.Float(string="%")
    unit_price = fields.Float(string="Unit Price")

    sale_product_id = fields.Many2one('sale.order')

