# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class Location(models.Model):
    _name = 'location.type'
    _description = "Location Details"

    name = fields.Char(string="Tipo Locación",required=True)
    description = fields.Char(string="Descripción")


class Alfombra(models.Model):
    _name = 'alfombra.alfombra'
    _description = "Alfombra Details"

    name = fields.Char(string="Alfombra",required=True)
    description = fields.Char(string="Descripción")


class Piso(models.Model):
    _name = 'piso.piso'
    _description = "Piso Details"

    name = fields.Char(string="Piso",required=True)
    description = fields.Char(string="Descripción")


class Vidrio(models.Model):
    _name = 'vidrio.vidrio'
    _description = "Vidrio Details"

    name = fields.Char(string="Vidrio",required=True)
    description = fields.Char(string="Descripción")


class FurniturePiece(models.Model):
    _name = 'furniture.piece'
    _description = "Furniture Piece"

    name = fields.Char(string="Mueble",required=True)
    description = fields.Char(string="Descripción")


class Otro(models.Model):
    _name = 'otro.otro'
    _description = "Otro Details"

    name = fields.Char(string="Otro",required=True)
    description = fields.Char(string="Descripción")


class ProductCategory(models.Model):
    _name= "machinery.machinery"
    _description = "Machinery Details"

    name = fields.Char(string="Maquinaria",required=True)
    description = fields.Char(string="Descripción")


# class TipoLocation(models.Model):
#     _name = 'tipo.location'
#     _description = "Tipo Location"

#     name = fields.Char(string="Tipo Locación",required=True)
#     description = fields.Char(string="Descripción")


class Condition(models.Model):
    _name = 'condition.condition'
    _description = "Condition Details"

    name = fields.Char(string="Cond",required=True)
    description = fields.Char(string="Descripción")


class BaseElement(models.Model):
    _name = 'base.element'
    _description = "Base Element"

    name = fields.Char(string="Elemento Base",required=True)
    description = fields.Char(string="Descripción")


class City(models.Model):
    _name = 'city.city'
    _description = "City Details"

    name = fields.Char(string="Ciudad",required=True)
    description = fields.Char(string="Descripción")


class ProductCategory(models.Model):
    _inherit= "product.category"
    _description = "Product Category"

    name = fields.Char(string="Categoría",required=True)
    description = fields.Char(string="Descripción")

