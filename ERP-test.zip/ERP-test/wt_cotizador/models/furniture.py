# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class FurniturePiece(models.Model):
    _name = 'furniture.piece'
    _description = "Furniture Piece"

    name = fields.Char(string="Mueble",required=True)
    description = fields.Char(string="Descripción")